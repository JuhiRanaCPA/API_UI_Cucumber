package steps;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import requestBody.RequestBody;

import java.util.ArrayList;
import java.util.List;

public class Alpine_Cert_DNS_Common_Steps extends RequestBody {


    @Then("Api successfully")
    public void apiSuccessful() {
        System.out.print("successful");
    }


    @When("I post {string} to the list with the following information:")
    public void readingTable(String apiname, DataTable dataTable) {
        String url = baseUri;
        switch (apiname) {
            case "organization":
                strBody = organization_StrBody(dataTable);
                url = url + "api/v1/organization";
                orgId = getValueFromResponseInString(url, strBody, "id", "POST");
                log.info("orgId: " + orgId);
                System.out.print("orgId: " + orgId);
                if (orgId == null) {
                    contactId = "";
                } else {
                    contactId = getValueFromResponseInString("contacts[0].id");

                }
                break;
            case "cert":
                strBody = cert_StrBody(dataTable);
                url = url + "api/v1/order";
                statusList.add(PASS);
                orderId = getValueFromResponseInString(url, strBody, "id", "POST");
                break;
            case "order":
                strBody = order_StrBody(dataTable);
                url = url + "api/v1/order";
                statusList.add(PASS);
                resourceId = getValueFromResponseInString(url, strBody, "id", "POST");
                if (resourceId == null) {
                    certId = "";
                } else {
                    certId = getValueFromResponseInString("cert");
                }
                break;
            case "orderFromProvider":
                strBody = orderFromProverId_StrBody(dataTable);
                url = url + "api/v1/order/createFromProvider";
                statusList.add(PASS);
                resourceId = getValueFromResponseInString(url, strBody, "id", "POST");
                break;
            case "domain":
                strBody = domain_StrBody(dataTable);
                url = url + "api/v1/domain";
                domainId = getValueFromResponseInString(url, strBody, "id", "POST");
                statusList.add(PASS);
                break;
            case "zone":
                strBody = getZone_StrBody(dataTable);
                url = url + "api/v1/zone";
                zoneId = getValueFromResponseInString(url, strBody, "id", "POST");
                statusList.add(PASS);
                break;
            case "record":
                strBody = getRecord_StrBody(dataTable);
                url = url + "api/v1/record";
                recordId = getValueFromResponseInString(url, strBody, "id", "POST");
                statusList.add(PASS);
                break;
            case "webForwarding":
                strBody = getWebForwarding_StrBody(dataTable);
                url = url + "api/v1/webForwarding";
                webForwardingId = getValueFromResponseInString(url, strBody, "id", "POST");
                statusList.add(PASS);
                break;

            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }

        assertCheck(FAIL, statusList);

    }

    @When("I patch {string} to the list with key {string} and value {string}")
    public void patchreadingTable(String apiname, String key, String value)  {
        String url = baseUri;
        switch (apiname) {
            case "record":
                strBody = getRecord_StrBody_Patch(key, value);
                url = url + "api/v1/record/" + recordId;
                setResponse(url, "PATCH", strBody);
                statusList.add(PASS);
                break;
            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }

        assertCheck(FAIL, statusList);

    }

    @Given("I authenticate with MarkMonitor for {string}")
    public void iAuthenticateWithMarkMonitor(String api_Type) {
        apiType = api_Type;
        getAccessToken(apiType);

    }

    @Then("I should have my entry in the {string} List")
    public void iShouldHaveMyEntryInTheOrganizationList(String apiname) {
        String url = baseUri;
        switch (apiname) {
            case "organization":
                url = url + "api/v1/organization/" + orgId;
                statusList.add(PASS);
                break;
            case "cert":
                url = url + "api/v1/cert/" + certId;
                statusList.add(PASS);
                break;
            case "order":
                url = url + "api/v1/order/" + resourceId;
                statusList.add(PASS);
                break;
            case "domain":
                url = url + "api/v1/domain/" + domainId;
                statusList.add(PASS);
                break;
            case "contact":
                url = url + "api/v1/contact/" + contactId;
                statusList.add(PASS);
                break;
            case "zone":
                url = url + "api/v1/zone/" + zoneId;
                statusList.add(PASS);
                break;
            case "record":
                url = url + "api/v1/record/" + recordId;
                statusList.add(PASS);
                break;
            case "webForwarding":
                url = url + "api/v1/webForwarding/" + webForwardingId;
                statusList.add(PASS);
                break;
            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }
        validateStatusCode(url, "", 200, "GET");
        assertCheck(FAIL, statusList);
    }


    @Then("The status code should be {string}")
    public void theStatusCodeShouldBe(String status) {
        validateStatusCodeFromResponse(Integer.parseInt(status));
    }


    @And("I DELETE my {string} from the list")
    public void iDELETEMyFromTheList(String apiname) {
        String url = baseUri;
        switch (apiname) {
            case "organization":
                url = url + "api/v1/organization/" + orgId;
                statusList.add(PASS);
                break;
            case "order":
                url = url + "api/v1/order/" + resourceId;
                statusList.add(PASS);
                break;
            case "domain":
                url = url + "api/v1/domain/" + domainId;
                statusList.add(PASS);
                break;
            case "contact":
                url = url + "api/v1/contact/" + contactId;
                statusList.add(PASS);
                break;
            case "zone":
                url = url + "api/v1/zone/" + zoneId;
                statusList.add(PASS);
                break;
            case "record":
                url = url + "api/v1/record/" + recordId;
                statusList.add(PASS);
                break;
            case "webForwarding":
                url = url + "api/v1/webForwarding/" + webForwardingId;
                statusList.add(PASS);
                break;
            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }

        if (getStatusCode(url, "", "GET") == 200) {
            setResponse(url, "DELETE", "");
            validateStatusCodeFromResponse(200);
        }
        assertCheck(FAIL, statusList);
    }


    @And("The status message should be {string}")
    public void theStatusMessageShouldBe(String response) {
        validateResponseMessage(response);
    }

    @And("In response I should get {string} in {string} keyword")
    public void inResponseIShouldGetInKeyword(String value, String key) {
        validateKeyValueFromResponse(key, value);
    }

    @And("Response should contain {string} in {string} {string} {string} keyword")
    public void responseShouldContainInKeyword(String value, String key, String idtype, String part2) {
        String expectedvalue = value + " " + resourceId + " " + part2;
        validateKeyValueFromResponse(key, expectedvalue);
    }

    @And("Response should contain {string} in {string} keyword")
    public void inResponseIShouldcontainInKeyword(String value, String key) {
        JsonPath jsonPath = getJsonPath();
        log.info("Response found successfully");
        log.info("Actual Parameter Value: " + jsonPath.get(key) + ", Expected Key Value: " + value);
        String actualvalue = jsonPath.get(key);
        if (actualvalue.contains(value))
            statusList.add(PASS);
        else
            statusList.add(FAIL);
        assertCheck(FAIL, statusList);
    }

    @When("I create a request body for {string} with the {string} and value {string} and send post request")
    public void iCreateARequestBodyWithTheAndValue(String requestType, String field, String value){
        switch (requestType) {
            case "organization":
                strBody = organization_StrBody(field, value);
                orgId = getValueFromResponseInString(baseUri + "api/v1/organization", strBody, "id", "POST");
                statusList.add(PASS);
                break;
            case "order":
                strBody = order_StrBody(field, value);
                resourceId = getValueFromResponseInString(baseUri + "api/v1/order", strBody, "id", "POST");
                statusList.add(PASS);
                break;
            case "domain":
                strBody = domain_StrBody(field, value);
                domainId = getValueFromResponseInString(baseUri + "api/v1/domain", strBody, "id", "POST");
                statusList.add(PASS);
                break;
            case "cert":
                certString = cert_StrBody(field, value);
                certId = getValueFromResponseInString(baseUri + "api/v1/domain", certString, "id", "POST");
                break;
            case "zone":
                zoneString = getZone_StrBody(field, value);
                zoneId = getValueFromResponseInString(baseUri + "api/v1/zone", zoneString, "id", "POST");
                break;
            case "record":
                recordString = getRecord_StrBody(field, value);
                recordId = getValueFromResponseInString(baseUri + "api/v1/record", recordString, "id", "POST");
                break;

            case "webForwarding":
                webForwardingId = getWebForwarding_StrBody(field, value);
                recordId = getValueFromResponseInString(baseUri + "api/v1/webForwarding", webForwardingId, "id", "POST");
                break;
            default:
                log.info("Menu item not found");
                statusList.add(FAIL);
                break;
        }
        assertCheck(FAIL, statusList);
    }

    @Then("The status code should be <Status_Code>")
    public void theStatusCodeShouldBeStatus_Code() {
    }


    @Then("I send {string} request for {string} for created ids to validate performance response with benchmark time")
    public void iSendDELETE_RequestForToValidatePerformanceResponseWithBenchmarkTime(String action, String requestModule) {
        String url = baseUri + "api/v1/" + requestModule + "/";
        List<String> idlist = null;
        switch (requestModule) {
            case "organization":
                idlist = orglist;
                statusList.add(PASS);
                break;
            case "order":
                idlist = resourceIdlist;
                statusList.add(PASS);
                break;
            case "domain":
                idlist = domainIdlist;
                statusList.add(PASS);
                break;
            case "contact":
                idlist = contactIdlist;
                statusList.add(PASS);
                break;
            case "record":
                idlist = recordIdlist;
                statusList.add(PASS);
                break;
            default:
                log.info("Menu item not found");
                statusList.add(FAIL);
                break;
        }
        statusList.add(validateResponseTime(action + "_" + requestModule, url, "", "", action, idlist));
        idlist.clear();
        assertCheck(FAIL, statusList);
    }

    @Then("I send PATCH request for action {string} {string} for created ids to validate performance response with benchmark time")
    public void iSendPATCHRequestForForCreatedIdsToValidatePerformanceResponseWithBenchmarkTime(String action, String requestModule) {
        String url = baseUri + "api/v1/" + requestModule + "/";
        List<String> idlist = null;
        switch (requestModule) {
            case "organization":
                idlist = orglist;
                statusList.add(PASS);
                break;
            case "order":
                idlist = resourceIdlist;
                statusList.add(PASS);
                break;
            default:
                log.info("Menu item not found");
                statusList.add(FAIL);
                break;
        }
        statusList.add(validateResponseTime("PATCH_" + requestModule, url, action, "", "PATCH", idlist));
        assertCheck(FAIL, statusList);
    }

    @When("I send {string} request for {string} to validate performance response with benchmark time")
    public void iSendRequestForTimesToValidatePerformanceResponseWithFollowingInformation(String requestType, String requestModule) {
        String url = baseUri;
        if (requestType.equalsIgnoreCase("GET") || requestType.equalsIgnoreCase("GET_ALL")) {
            strBody = "";
        }
        switch (requestModule) {
            case "organization":
                url = url + "api/v1/organization";
                if (!requestType.equalsIgnoreCase("POST") & !requestType.equalsIgnoreCase("GET_ALL")) {
                    url = url + "/" + orgId;
                }
                statusList.add(PASS);
                break;
            case "order":
                url = url + "api/v1/order";
                if (!requestType.equalsIgnoreCase("POST") & !requestType.equalsIgnoreCase("GET_ALL")) {
                    url = url + "/" + resourceId;
                }
                statusList.add(PASS);
                break;
            case "domain":
                url = url + "api/v1/domain";
                if (!requestType.equalsIgnoreCase("POST") & !requestType.equalsIgnoreCase("GET_ALL")) {
                    url = url + "/" + domainId;
                }
                statusList.add(PASS);
                break;
            case "contact":
                url = url + "api/v1/contact";
                if (!requestType.equalsIgnoreCase("POST") & !requestType.equalsIgnoreCase("GET_ALL")) {
                    url = url + "/" + contactId;
                }
                statusList.add(PASS);
                break;
            case "cert":
                url = url + "api/v1/cert";
                if (!requestType.equalsIgnoreCase("POST") & !requestType.equalsIgnoreCase("GET_ALL")) {
                    url = url + "/" + certId;
                } else {
                    url = url + "?accountId=55";
                }
                statusList.add(PASS);
                break;
            case "zone":
                url = url + "api/v1/zone";
                if (!requestType.equalsIgnoreCase("POST") & !requestType.equalsIgnoreCase("GET_ALL")) {
                    url = url + "/" + zoneId;
                }
                statusList.add(PASS);
                break;
            case "zoneTemplate":
                url = url + "api/v1/zoneTemplate";
                if (!requestType.equalsIgnoreCase("POST") & !requestType.equalsIgnoreCase("GET_ALL")) {
                    url = url + "/" + zoneId;
                }
                statusList.add(PASS);
                break;
            case "record":
                url = url + "api/v1/record";
                if (!requestType.equalsIgnoreCase("POST") & !requestType.equalsIgnoreCase("GET_ALL")) {
                    url = url + "/" + recordId;
                }
                statusList.add(PASS);
                break;
            case "webForwarding":
                url = url + "api/v1/webForwarding";
                if (!requestType.equalsIgnoreCase("POST") & !requestType.equalsIgnoreCase("GET_ALL")) {
                    url = url + "/" + webForwardingId;
                }
                statusList.add(PASS);
                break;
            case "recordsbyZone":
                url = url + "api/v1/record?page=0&zoneId=" + zoneId;
                break;
            default:
                log.info("Menu item not found");
                statusList.add(PASS);
                statusList.add(FAIL);
                break;
        }
        if (requestType.equalsIgnoreCase("GET_ALL")) {
            requestType = "GET";
        }
        statusList.add(validateResponseTime(requestType + "_" + requestModule, url, strBody, requestType));
        assertCheck(FAIL, statusList);
    }

    @When("I create request body for {string}:")
    public void iCreateRequestBodyForOrganization(String apiType, DataTable dataTable) {
        switch (apiType) {
            case "organization":
                strBody = organization_StrBody(dataTable);
                statusList.add(PASS);
                break;
            case "contacts":
//                strBody = organization_WithContacts_StrBody(dataTable);
                statusList.add(PASS);
                break;
            case "order":
                strBody = order_StrBody(dataTable);
                statusList.add(PASS);
                break;
            case "domain":
                strBody = domain_StrBody(dataTable);
                statusList.add(PASS);
                break;
            case "zone":
                strBody = getZone_StrBody(dataTable);
                statusList.add(PASS);
                break;
            case "record":
                strBody = getRecord_StrBody(dataTable);
                statusList.add(PASS);
                break;
            case "webForwarding":
                strBody = getWebForwarding_StrBody(dataTable);
                statusList.add(PASS);
                break;
            default:
                log.info("Menu item not found");
                statusList.add(FAIL);
                break;
        }
        assertCheck(FAIL, statusList);
    }

    @And("I clear my {string} list")
    public void iClearMyList(String typeName) {
        switch (typeName) {
            case "organizationid":
                orglist.clear();
                statusList.add(PASS);
                break;
            case "orderid":
                resourceIdlist.clear();
                statusList.add(PASS);
                break;
            case "domainid":
                domainIdlist.clear();
                statusList.add(PASS);
                break;
            case "recordid":
                recordIdlist.clear();
                statusList.add(PASS);
                break;
            default:
                log.info("Menu item not found");
                statusList.add(FAIL);
                break;
        }
        assertCheck(FAIL, statusList);
    }

    @And("I save my {string} in the list")
    public void iSaveMyInTheList(String typeName) {
        switch (typeName) {
            case "organizationid":
                orglist.add(orgId);
                statusList.add(PASS);
                break;
            case "orderid":
                resourceIdlist.add(resourceId);
                statusList.add(PASS);
                break;
            case "domainid":
                domainIdlist.add(domainId);
                statusList.add(PASS);
                break;
            case "contactid":
                contactIdlist.add(contactId);
                statusList.add(PASS);
                break;
            case "recordId":
                recordIdlist.add(recordId);
                statusList.add(PASS);
                break;
            default:
                log.info("Menu item not found");
                statusList.add(FAIL);
                break;
        }
        assertCheck(FAIL, statusList);
    }

    @And("I DELETE my {string} from the added list")
    public void iDELETEMyFromTheAddedList(String apiname) {
        List<String> IdList = new ArrayList<>();
        String url = baseUri;
        switch (apiname) {
            case "organization":
                url = url + "api/v1/organization/";
                IdList = orglist;
                statusList.add(PASS);
                break;
            case "orderids":
                url = url + "api/v1/order/";
                IdList = resourceIdlist;
                statusList.add(PASS);
                break;
            case "domainids":
                url = url + "api/v1/domain/";
                IdList = domainIdlist;
                statusList.add(PASS);
                break;
            case "recordIds":
                url = url + "api/v1/record/";
                IdList = recordIdlist;
                statusList.add(PASS);
                break;
//            case "cert":
//                url = url + "api/v1/order/" + orderId;
//                statusList.add(PASS);
//                break;
            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }
        for (String ele : IdList) {
            if (getStatusCode(url + ele, "", "GET") == 200) {
                setResponse(url + ele, "DELETE", "");
                validateStatusCodeFromResponse(200);
            } else {
                log.info("UUID is already not available");
            }

        }
        assertCheck(FAIL, statusList);
    }


    @When("I try to DELETE my {string} from the list")
    public void iTryDELETEMyFromTheList(String apiname) {
        String url = baseUri;
        switch (apiname) {
            case "organization":
                url = url + "api/v1/organization/" + orgId;
                statusList.add(PASS);
                break;
            case "order":
                url = url + "api/v1/order/" + resourceId;
                statusList.add(PASS);
                break;
            case "cert":
                url = url + "api/v1/order/" + orderId;
                statusList.add(PASS);
                break;
            case "domain":
                url = url + "api/v1/domain/" + domainId;
                statusList.add(PASS);
                break;
            case "contact":
                url = url + "api/v1/contact/" + contactId;
                statusList.add(PASS);
                break;
            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }
        setResponse(url, "DELETE", "");
        assertCheck(FAIL, statusList);
    }


    @And("I should get following values for {string} when I search by {string} and {string}")
    public void iShouldGetFollowingValuesForOrderWhenISearchBy(String module, String searchType, String searchValue, DataTable dataTable) {
        String url = baseUri + "api/v1/" + module;
        if (searchType.equalsIgnoreCase("orderId")) {
            url = url + "/" + resourceId;
        } else if (searchType.equalsIgnoreCase("orgId")) {
            url = url + "/" + orgId;
        } else if (searchType.equalsIgnoreCase("organization_name")) {
            url = url + "?name=" + orgName;
        } else if (searchType.equalsIgnoreCase("domainId")) {
            url = url + "/" + domainId;
        } else if (searchType.equalsIgnoreCase("contactId")) {
            url = url + "/" + contactId;
        } else if (searchType.equalsIgnoreCase("certId")) {
            url = url + "/" + certId;
        } else if (searchType.equalsIgnoreCase("zoneId")) {
            url = url + "/" + zoneId;
        } else if (searchType.equalsIgnoreCase("recordId")) {
            url = url + "/" + recordId;
        } else if (searchType.equalsIgnoreCase("zone for record")) {
            url = url + "?" + "page=0&zoneId=" + searchValue;
        } else if (searchType.equalsIgnoreCase("webForwardingId")) {
            url = url + "/" + webForwardingId;
        } else {
            url = url + "?" + searchType + "=" + searchValue;
        }

        setResponse(url, "GET", "");
        List<List<String>> rows = dataTable.asLists(String.class);
        for (List<String> columns : rows) {
            String expectedValue = columns.get(1);
            String ele = columns.get(0);
            if (ele.contains("_embedded")) {
                List<String> actualValues = getAllValuesFromResponse(url, "", ele, "GET");
                if (actualValues.toString().contains(expectedValue))
                    statusList.add(PASS);
                else
                    statusList.add(FAIL);
            } else {
                if (ele.equalsIgnoreCase("organization") || ele.equalsIgnoreCase("organizationId")) {
                    expectedValue = orgId;
                } else if (ele.equalsIgnoreCase("Order") || ele.equalsIgnoreCase("OrderId")) {
                    expectedValue = resourceId;
                } else if (ele.equalsIgnoreCase("domain") || ele.equalsIgnoreCase("domainId")) {
                    expectedValue = domainId;
                } else if (ele.equalsIgnoreCase("contact") || ele.equalsIgnoreCase("contactId")) {
                    expectedValue = contactId;
                } else if (ele.equalsIgnoreCase("domainName")) {
                    expectedValue = domainName;
                    ele = "name";
                } else if (ele.equalsIgnoreCase("cert") || ele.equalsIgnoreCase("certId")) {
                    expectedValue = certId;
                }
                Object actualValue = getValueFromResponse(url, "", ele, "GET");
                if (actualValue.toString().contains(expectedValue)) {
                    statusList.add(PASS);
                } else {
                    System.out.print("actual value:" + actualValue + "  expected was: " + columns.get(1));
                    statusList.add(FAIL);

                }
            }


        }
        assertCheck(FAIL, statusList);

    }

    @And("In order response I should get organization Id in {string} keyword")
    public void inOrderResponseIShouldGetInKeyword(String key) {
        validateKeyValueFromResponse(key, orgId);
    }

    @When("I patch an {string} for {string} action")
    public void iPatchAnForAction(String apiname, String action) {
        String url = baseUri;
        switch (apiname) {
            case "order":
                url = url + "api/v1/order/" + resourceId + "/" + action;
                statusList.add(PASS);
                setResponse(url, "PATCH", "");
                break;
            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }

        assertCheck(FAIL, statusList);
    }


    @Then("I send {string} request for \\{string} for created ids to validate performance response with benchmark time")
    public void iSendRequestForStringForCreatedIdsToValidatePerformanceResponseWithBenchmarkTime(String arg0) {
    }


    @And("I should not have my entry in the {string} List")

    public void iShouldnotHaveMyEntryInTheOrganizationList(String apiname) {
        String url = baseUri;
        switch (apiname) {
            case "organization":
                url = url + "api/v1/organization/" + orgId;
                statusList.add(PASS);
                break;
            case "cert":
                url = url + "api/v1/cert/" + certId;
                statusList.add(PASS);
                break;
            case "order":
                url = url + "api/v1/order/" + resourceId;
                statusList.add(PASS);
                break;
            case "domain":
                url = url + "api/v1/domain/" + domainId;
                statusList.add(PASS);
                break;
            case "contact":
                url = url + "api/v1/contact/" + contactId;
                statusList.add(PASS);
                break;
            case "record":
                url = url + "api/v1/record/" + recordId;
                statusList.add(PASS);
                break;
            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }
        Integer actualstatuscode = getStatusCode(url, "", "GET");
        if (actualstatuscode == 400 || actualstatuscode == 404) {
            statusList.add(PASS);
        } else {
            statusList.add(FAIL);
        }
        assertCheck(FAIL, statusList);

    }


    @And("I create request body for contacts with the following information:")
    public void iCreateRequestBodyForContactsWithWithTheFollowingInformation(DataTable table) {
        contactString = contact_StrBody(table);
        assertCheck(FAIL, statusList);
    }

    @And("I append another contacts in the created requestbody with following information:")
    public void iAppendAnotherContactsInTheCreatedRequestbodyWithFollowingInformation(DataTable table) {
        contactString = contactString + "," + contact_StrBody(table);
    }

    @When("I create a request body for {string} with the {string} and value {string}")
    public void iCreateARequestBodyForContactsWithTheAndValue(String type, String field, String value) {
        switch (type) {
            case "contact":
                contactString = contact_StrBody(field, value);
                statusList.add(PASS);
                break;
            case "cert":
                certString = cert_StrBody(field, value);
                statusList.add(PASS);
                break;
            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }

        assertCheck(FAIL, statusList);
    }

    @When("I update {string} with the following information:")
    public void iUpdateWithTheFollowingInformation(String type, DataTable dataTable) {
        String url = baseUri;
        switch (type) {
            case "contact":
                strBody = contact_StrBody(dataTable);
                url = url + "api/v1/contact/" + contactId;
                statusList.add(PASS);
                setResponse(url, "PATCH", strBody);
                break;
            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }
        assertCheck(FAIL, statusList);
    }

    @When("I update {string} with {string} and {string}")
    public void iUpdateWithAnd(String type, String field_name, String field_Value) {
        String url = baseUri;
        switch (type) {
            case "contact":
                strBody = contact_StrBody(field_name, field_Value);
                url = url + "api/v1/contact/" + contactId;
                statusList.add(PASS);
                setResponse(url, "PATCH", strBody);
                break;
            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }
        assertCheck(FAIL, statusList);
    }

    @Then("I should get {string} values for {string} for {string} when I search by {string} and {string}")
    public void iShouldGetValuesForFor(String field_Value, String field_name, String module, String
            searchType, String searchValue) {
        String url = baseUri + "api/v1/" + module;
        if (searchType.equalsIgnoreCase("orderId")) {
            url = url + "/" + resourceId;
        } else if (searchType.equalsIgnoreCase("orgId")) {
            url = url + "/" + orgId;
        } else if (searchType.equalsIgnoreCase("organization_name")) {
            url = url + "?name=" + orgName;
        } else if (searchType.equalsIgnoreCase("domainId")) {
            url = url + "/" + domainId;
        } else if (searchType.equalsIgnoreCase("contactId")) {
            url = url + "/" + contactId;
        } else {
            url = url + "?" + searchType + "=" + searchValue;
        }

        setResponse(url, "GET", "");

        String expectedValue = field_Value;
        String ele = field_name;
        if (ele.contains("_embedded")) {
            List<String> actualValues = getAllValuesFromResponse(url, "", ele, "GET");
            if (actualValues.toString().contains(expectedValue))
                statusList.add(PASS);
            else
                statusList.add(FAIL);
        } else {
            if (ele.equalsIgnoreCase("organization") || ele.equalsIgnoreCase("organizationId")) {
                expectedValue = orgId;
            } else if (ele.equalsIgnoreCase("Order") || ele.equalsIgnoreCase("OrderId")) {
                expectedValue = resourceId;
            } else if (ele.equalsIgnoreCase("domain") || ele.equalsIgnoreCase("domainId")) {
                expectedValue = domainId;
            } else if (ele.equalsIgnoreCase("contact") || ele.equalsIgnoreCase("contactId")) {
                expectedValue = contactId;
            } else if (ele.equalsIgnoreCase("domainName")) {
                expectedValue = domainName;
                ele = "name";
            }
            Object actualValue = getValueFromResponse(url, "", ele, "GET");
            if (actualValue.toString().contains(expectedValue)) {
                statusList.add(PASS);
            } else {
                System.out.print("actual value:" + actualValue + "  expected was: " + field_Value);
                statusList.add(FAIL);
            }
        }
        assertCheck(FAIL, statusList);
    }


    @Then("I send {string} request for {string} By {string} with {string} to validate performance response with benchmark time")
    public void iSendRequestForByToValidatePerformanceResponseWithBenchmarkTime(String requestType, String
            module, String searchType, String searchValue) {
        String url = baseUri + "api/v1/" + module;
        if (requestType.equalsIgnoreCase("GET") || requestType.equalsIgnoreCase("DELETE")) {
            strBody = "";
        }

        if (searchType.equalsIgnoreCase("orderId")) {
            url = url + "/" + resourceId;
        } else if (searchType.equalsIgnoreCase("orgId")) {
            url = url + "/" + orgId;
        } else if (searchType.equalsIgnoreCase("organization_name")) {
            url = url + "?name=" + orgName;
        } else if (searchType.equalsIgnoreCase("domainId")) {
            url = url + "/" + domainId;
        } else if (searchType.equalsIgnoreCase("contactId")) {
            url = url + "/" + contactId;
        } else {
            url = url + "?" + searchType + "=" + searchValue;
        }

        statusList.add(validateResponseTime(requestType + "_" + module, url, strBody, requestType));
        assertCheck(FAIL, statusList);
    }

    @When("I create request body for {string} with the following information:")
    public void iCreateRequestBodyForCertWithTheFollowingInformation(String type, DataTable table) {
        switch (type) {
            case "cert":
                certString = cert_StrBody(table);
                break;
            case "order":
                orderString = order_StrBody(table);
                break;
            default:
                log.info("apiname not found");
                statusList.add(FAIL);
                break;
        }
        assertCheck(FAIL, statusList);
    }

    @When("I post organization with the same name")
    public void iPostOrganizationWithTheSameName() {

    }

    @When("I post {string} with the same name")
    public void iPostWithTheSameName(String type) {
        setResponse(baseUri + "api/v1/" + type, "POST", strBody);
        assertCheck(FAIL, statusList);
    }


    @And("I should get following values for organization when I search by {string} and {string}")
    public void iShouldGetFollowingValuesForOrganizationWhenISearchBy(String searchType, String
            searchValue, DataTable dataTable) {
        String url = baseUri;
        if (searchType.equalsIgnoreCase("orgId")) {
            url = url + "api/v1/organization/" + orgId;
        } else if (searchType.equalsIgnoreCase("name")) {
            url = url + "api/v1/organization?" + searchType + "=" + orgName;
        } else {
            url = url + "api/v1/organization?" + searchType + "=" + searchValue;
        }

        setResponse(url, "GET", "");
        List<List<String>> rows = dataTable.asLists(String.class);

        for (List<String> columns : rows) {
            String ele = columns.get(0);
            if (!searchType.equalsIgnoreCase("orgId")) {
                ele = "_embedded.organizations." + ele;
                List<String> actualValues = getAllValuesFromResponse(url, "", ele, "GET");
                if (actualValues.contains(columns.get(1)))
                    statusList.add(PASS);
                else
                    statusList.add(FAIL);
            } else {
                String actualValue = getValueFromResponseInString(url, "", columns.get(0), "GET");
                if (actualValue.contains(columns.get(1))) {
                    statusList.add(PASS);
                } else {
                    System.out.print("actual value:" + actualValue + "  expected was: " + columns.get(1));
                    statusList.add(FAIL);
                    ;
                }
            }


        }
        assertCheck(FAIL, statusList);

    }

    @Then("I send {string} request for organization By {string} with {string} to validate performance response with benchmark time")
    public void iSendRequestForByToValidatePerformanceResponseWithBenchmarkTime(String requestType, String
            bytype, String typeValue) {
        if (requestType.equalsIgnoreCase("GET") || requestType.equalsIgnoreCase("DELETE")) {
            strBody = "";
        }
        if (bytype.equalsIgnoreCase("name")) {
            if (typeValue.equalsIgnoreCase("##################")) {
                typeValue = orgName;
            }
        }
        String url = baseUri + "api/v1/organization?" + bytype + "=" + typeValue;
        statusList.add(validateResponseTime(requestType + "_Organization", url, strBody, requestType));
        assertCheck(FAIL, statusList);
    }

    @And("I DELETE my organization from the list with orders")
    public void iDELETEMyFromTheListWithOrders() {
        String url = baseUri + "api/v1/organization/" + orgId;
        setResponse(url, "DELETE", "");
    }

//***********************DNS methods ***************************//

    @When("I create request body for zone with the following information:")
    public void iCreateRequestBodyForZoneWithTheFollowingInformation(DataTable table) {
        zoneString = getZone_StrBody(table);
        assertCheck(FAIL, statusList);
    }

    @When("I post organization with the same name created in API_Zone_TC_01")
    public void iPostZoneWithTheSameName() {
        setResponse(baseUri + "api/v1/zone", "POST", strBody);
    }


    @And("hello jdjdjhdjd")
    public void helloJdjdjhdjd() {
        System.out.print("printing hello");
    }
}
