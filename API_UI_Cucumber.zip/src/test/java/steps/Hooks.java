package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import library.Functions;


public class Hooks extends Functions {

    @Before
    public void openBrowser() {
//        System.out.print("Running API test");
//        if(browser.equals("")){
//            System.out.print("Running API test");
//            statusList.add("Pass");
//        }
//        else {
//            statusList.add(openBrowser(browser));
//        }
//        assertCheck("Fail", statusList);
    }

    @After
    public void trashBrowser() {
        if(driver!=null){
            statusList.add(closeBrowser());
        }

    }

}
