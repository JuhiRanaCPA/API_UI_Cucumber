package library;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.apache.log4j.Logger;
import org.hamcrest.MatcherAssert;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static java.time.Duration.ofSeconds;
import static library.PropertiesUtil.getProperty;
import static org.hamcrest.Matchers.hasItem;
//import static org.junit.Assert.assertFalse;
import static org.junit.Assert.*;

public class Functions {
    protected static WebDriver driver = null;
    protected static JavascriptExecutor jsExecutor = null;
    protected static String browser = System.getProperty("Browser");
    protected final static Logger log;
    protected static Actions actions;
    protected static List<String> statusList = new ArrayList<>();
    public static final String PASS = "Pass";
    public static final String FAIL = "Fail";

    static Response response;
    public static ExcelUtility xlUtil = new ExcelUtility("MarkMonitor");
    protected static String baseUri = System.getProperty("baseUri");
    protected static String baseUriDns = System.getProperty("baseUriDns");
    protected static String appUrl = System.getProperty("appUrl");
    protected static String appUrlDns = System.getProperty("appUrlDns");
    protected static String email = System.getProperty("email");
    protected static String password = System.getProperty("password");
    public static String apiType = System.getProperty("apiType");
    public static String apiKey = System.getProperty("apiKey");
    public static String apiKeyName = System.getProperty("apiKeyName");
    protected int BENCHMARK_RESPONSE_TIME = 2000;
    public static String strBody = "";
    public static String contactString = "";
    public static String certString = "";
    public static String orderString = "";
    public static String recordString = "";
    public static List<String> resourceIdlist = new ArrayList<>();
    public static List<String> orglist = new ArrayList<>();
    public static List<String> domainIdlist = new ArrayList<>();
    public static List<String> contactIdlist = new ArrayList<>();
    public static List<String> orderdlist = new ArrayList<>();
    public static List<String> recordIdlist = new ArrayList<>();
    public static String orgId = "";
    public static String orderId = "";
    public static String certId = "";
    public static String resourceId = "";
    public static String domainId = "";
    public static String contactId = "";

    //****************    DNS  ********************//
    public static String zoneString = "";
    public static String zoneId = "";
    public static String recordId = "";
    public static String webForwardingId ="";
    public static String orgName = "";
    public static String zoneName = "";
    public static String domainName = "";
    public static String recordName = "";

    //*******************************************//

    static {
        log = Logger.getLogger("UILogger");
        log.info("Home Directory : " + System.getProperty("user.dir"));
        if (browser == null) {
            browser = "Chrome";
        }
        if (apiType == null) {
            apiType = "alipne_CERT";

        }
        if (baseUri == null) {
            //Test Environment
            if (apiType.equalsIgnoreCase("alipne_CERT")) {
                baseUri = "http://alpine-certs-staging.apps.okd.mm-corp.net/";
                appUrl = "http://alpine-certs-staging.apps.okd.mm-corp.net/";
            } else {
                baseUri = "http://alpine-dns-staging.apps.okd.mm-corp.net/";
                baseUri = "http://alpine-dns-staging.apps.okd.mm-corp.net/";
            }
            email = "**"; // Needs to provide the email manually to test it on local machine
            password = "";  // Needs to provide the password manually to test it on local machine
        }
        if (baseUriDns == null) {
            baseUriDns = "http://alpine-dns-staging.apps.okd.mm-corp.net/";
            appUrlDns = "http://alpine-dns-staging.apps.okd.mm-corp.net/";
            email = "**"; // Needs to provide the email manually to test it on local machine
            password = "";  // Needs to provide the password manually to test it on local machine
        }
        xlUtil.initializePerformanceSheet();
        RestAssured.baseURI = baseUri;
//        getAccessToken();


    }

    /**
     * Method Name: openBrowser
     * Parameters: browserType as String and cacheEnabled as boolean
     * Return Type: String
     * Exceptions: IllegalArgumentException
     * Objective: Opens browser instance on the browser provided from test case along with Cache Enabled or disabled
     **/


    public String openBrowser(String browser) {
        Functions.browser = browser;
        switch (browser.toLowerCase()) {

            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                FirefoxProfile ffProfile = new FirefoxProfile();
                ffProfile.setPreference("webdriver.log.driver", "OFF");
                System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE, "/dev/null");
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                firefoxOptions.setAcceptInsecureCerts(true);
                firefoxOptions.setCapability("--disable-extensions", true);
                driver = new FirefoxDriver(firefoxOptions);
                driver.manage().deleteAllCookies();
                break;
            case "chrome":
                WebDriverManager.chromedriver().setup();
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
                chromeOptions.setPageLoadStrategy(PageLoadStrategy.EAGER);
                chromeOptions.addArguments("--disable-features=VizDisplayCompositor");
                Map<String, Object> prefs = new HashMap<>();
                prefs.put("credentials_enable_service", false);
                prefs.put("profile.password_manager_enabled", false);
                chromeOptions.setExperimentalOption("prefs", prefs);
                chromeOptions.addArguments("--disable-notifications");
                chromeOptions.addArguments("--disable-extensions");
                chromeOptions.addArguments("--disable-arguments");
                chromeOptions.addArguments("--disable-infobars");
                chromeOptions.addArguments("-–disable-sync");
                chromeOptions.addArguments("--disable-gpu");
                chromeOptions.addArguments("--test-type");
                chromeOptions.addArguments("--test");
                driver = new ChromeDriver(chromeOptions);
                driver.manage().deleteAllCookies();
                break;
            case "ie":
                WebDriverManager.iedriver().arch32().setup();
                InternetExplorerOptions ieOptions = new InternetExplorerOptions();
                ieOptions.introduceFlakinessByIgnoringSecurityDomains();
                ieOptions.ignoreZoomSettings();
                ieOptions.destructivelyEnsureCleanSession();
                ieOptions.disableNativeEvents();
                ieOptions.requireWindowFocus();
                ieOptions.enablePersistentHovering();
                driver = new InternetExplorerDriver(ieOptions);
                driver.manage().deleteAllCookies();
                break;
            case "edge":
                WebDriverManager.edgedriver().setup();
                EdgeOptions options = new EdgeOptions();
                options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
                options.setPageLoadStrategy(PageLoadStrategy.EAGER);
                options.addArguments("--disable-features=VizDisplayCompositor");
                Map<String, Object> edgePrefs = new HashMap<>();
                edgePrefs.put("credentials_enable_service", false);
                edgePrefs.put("profile.password_manager_enabled", false);
                options.setExperimentalOption("prefs", edgePrefs);
                options.addArguments("--disable-notifications");
                options.addArguments("--disable-extensions");
                options.addArguments("--disable-arguments");
                options.addArguments("--disable-infobars");
                options.addArguments("-–disable-sync");
                options.addArguments("--disable-gpu");
                options.addArguments("--test-type");
                options.addArguments("--test");
                driver = new EdgeDriver(options);
                driver.manage().deleteAllCookies();
                break;
            case "headlesschrome":
                WebDriverManager.chromedriver().setup();
                chromeOptions = new ChromeOptions();
                chromeOptions.addArguments("--disable-gpu");
                chromeOptions.setHeadless(true);
                driver = new ChromeDriver(chromeOptions);
                break;
            default:
                log.info("Please enter a valid browser type", new IllegalArgumentException());
                return "Fail";
        }
        driver.manage().deleteAllCookies();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        jsExecutor = (JavascriptExecutor) driver;
        actions = new Actions(driver);
        log.info("Web driver initialized successfully");

        return "Pass";
    }

    /**
     * Method Name: closeBrowser
     * Parameters: None
     * Return Type: String
     * Exceptions: None
     * Objective: Close all browser instances
     **/

    public String closeBrowser() {
        if (driver != null) {
            driver.quit();
            log.info("Web driver trashed successfully");
            return "Pass";
        } else
            return "Fail";
    }

    /**
     * Method name: launch
     * Parameters: appUrl as String
     * Return Type: String
     * Objective: To launch the application with provided URL
     **/

    public String launch(String appUrl) {
        try {
            driver.get(appUrl);
            waitUntilAngularReady();
            return "Pass";
        } catch (Exception e) {
            log.fatal("Exception found: ", e);
            return "Fail";
        }
    }

    /**
     * Method name: findElement
     * Parameters: elementLocator as String
     * Return Type: WebElement
     * Objective: To find the element from webpage using the element locator defined in properties file
     **/

    public WebElement findElement(String elementLocator) {
        if (elementLocator.startsWith("//") || elementLocator.startsWith("(//")) {
            return driver.findElement(By.xpath(elementLocator));
        } else {
            return driver.findElement(By.xpath(getProperty(elementLocator)));
        }
    }

    /**
     * Method Name: findElements
     * Parameters: elementLocator as String
     * Return Type: List of WebElement
     * Exceptions: None
     * Objective: To find the list of WebElements using the elementLocator from properties file
     **/

    public List<WebElement> findElements(String elementLocator) {
        if (elementLocator.startsWith("(//") || elementLocator.startsWith("//"))
            return driver.findElements(By.xpath((elementLocator)));
        else
            return driver.findElements(By.xpath(getProperty(elementLocator)));
    }

    /**
     * Method Name: waitForJQueryLoad
     * Parameters: None
     * Return Type: None
     * Exceptions: None
     * Objective: To wait for JQuery to load
     */

    public void waitForJQueryLoad() {

        // Wait for jQuery to load
        WebDriver jsWaitDriver = driver;
        WebDriverWait jsWait = new WebDriverWait(jsWaitDriver, ofSeconds(10));
        JavascriptExecutor jsExec = (JavascriptExecutor) jsWaitDriver;
        ExpectedCondition<Boolean> jQueryLoad = driver -> ((Long) ((JavascriptExecutor) driver).executeScript("return jQuery.active") == 0);
        // Get JQuery is Ready
        boolean jqueryReady = (Boolean) jsExec.executeScript("return jQuery.active==0");
        // Wait JQuery until it is Ready!
        if (!jqueryReady) {
            log.info("JQuery is NOT Ready!");
            jsWait.until(jQueryLoad);
        } else {
            log.info("JQuery is Ready!");
        }
    }

    /**
     * Method Name: waitForAngularLoad
     * Parameters: None
     * Return Type: None
     * Exceptions: None
     * Objective: To wait for angular to load
     */

    public void waitForAngularLoad() {
        WebDriver jsWaitDriver = driver;
        JavascriptExecutor jsExec = (JavascriptExecutor) jsWaitDriver;
        WebDriverWait wait = new WebDriverWait(driver, ofSeconds(20));

        String angularReadyScript = "return angular.element(document).injector().get('$http').pendingRequests.length === 0";

        // Wait for ANGULAR to load
        ExpectedCondition<Boolean> angularLoad = driver -> Boolean.valueOf(((JavascriptExecutor) driver).executeScript(angularReadyScript).toString());

        // Get Angular is Ready
        boolean angularReady = Boolean.parseBoolean(jsExec.executeScript(angularReadyScript).toString());

        // Wait ANGULAR until it is Ready!
        if (!angularReady) {
            wait.until(angularLoad);
        } else {
            log.info("ANGULAR is Ready!");
        }
    }

    /**
     * Method Name: waitUntilJSReady
     * Parameters: None
     * Return Type: None
     * Exceptions: None
     * Objective: To wait until javascipt is ready
     */

    public void waitUntilJSReady() {
        WebDriver jsWaitDriver = driver;
        JavascriptExecutor jsExec = (JavascriptExecutor) jsWaitDriver;
        WebDriverWait wait = new WebDriverWait(driver, ofSeconds(20));

        // Wait for Javascript to load
        ExpectedCondition<Boolean> jsLoad = driver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");

        // Get JS is Ready
        boolean jsReady = (Boolean) jsExec.executeScript("return document.readyState").toString().equals("complete");

        // Wait Javascript until it is Ready!
        if (!jsReady) {
            wait.until(jsLoad);
        } else {
            log.info("JS is Ready!");
        }
    }

    /**
     * Method Name: waitUntilJQueryReady
     * Parameters: None
     * Return Type: None
     * Exceptions: None
     * Objective: To wait until jQuery is ready
     */

    public void waitUntilJQueryReady() {
        WebDriver jsWaitDriver = driver;
        JavascriptExecutor jsExec = (JavascriptExecutor) jsWaitDriver;

        // First check that JQuery is defined on the page. If it is, then wait AJAX
        Boolean jQueryDefined = (Boolean) jsExec.executeScript("return typeof jQuery != 'undefined'");
        if (jQueryDefined) {
            // Pre Wait for stability (Optional)
            sleep(20);

            // Wait JQuery Load
            waitForJQueryLoad();

            // Wait JS Load
            waitUntilJSReady();

            // Post Wait for stability (Optional)
            sleep(20);
        } else {
            log.info("jQuery is not defined on this site!");
        }
    }

    /**
     * Method Name: waitUntilAngularReady
     * Parameters: None
     * Return Type: None
     * Exceptions: None
     * Objective: To wait until angular is ready
     */

    public String waitUntilAngularReady() {
        try {
            WebDriver jsWaitDriver = driver;
            JavascriptExecutor jsExec = (JavascriptExecutor) jsWaitDriver;

            // First check that ANGULAR is defined on the page. If it is, then wait for ANGULAR
            Boolean angularUnDefined = (Boolean) jsExec.executeScript("return window.angular === undefined");
            if (!angularUnDefined) {
                Boolean angularInjectorUnDefined = (Boolean) jsExec.executeScript("return angular.element(document).injector() === undefined");
                if (!angularInjectorUnDefined) {
                    // Pre Wait for stability (Optional)
                    sleep(20);

                    // Wait Angular Load
                    waitForAngularLoad();

                    // Wait JS Load
                    waitUntilJSReady();

                    // Post Wait for stability (Optional)
                    sleep(20);
                } else {
                    log.info("Angular injector is not defined on this site!");
                }
            } else {
                log.info("Angular is not defined on this site!");
            }
            return "Pass";
        } catch (Exception e) {
            log.fatal("Exception found: ", e);
            return "Fail";
        }
    }

    /**
     * Method Name: sleep
     * Parameters: seconds as Integer
     * Return Type: None
     * Exceptions: None
     * Objective: To put a sleep for defined time duration
     */

    public void sleep(Integer seconds) {
        long secondsLong = (long) seconds;
        try {
            Thread.sleep(secondsLong);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method Name: waitAll
     * Parameters: milliseconds as Integer
     * Return Type: None
     * Exceptions: None
     * Objective: To put a wait for defined time duration
     */

    public void waitAll(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Method name: assertCheck
     * Parameters: status as String, list of String
     * Return Type: String
     * Exceptions: None
     * Objective: To verify the data of element
     */

    public void assertCheck(String verifyStatus, List<String> listOfStatus) {
        try {
            log.info("Value of list is " + listOfStatus);
            assertFalse(listOfStatus.contains(verifyStatus));
        } catch (Exception e) {
            log.fatal("Exception found: ", e);
        } finally {
            listOfStatus.clear();
            log.info("List after clearing " + listOfStatus);
        }
    }

    /**
     * Method name: waitForElementToBeVisible
     * Parameters: element as String
     * Return Type: WebElement
     * Exceptions: None
     * Objective: To wait 20 seconds for the element to visible
     */

    public String waitForElementToBeVisible(String element) {
        WebDriverWait dynamicWait = new WebDriverWait(driver, ofSeconds(20));
        WebElement elementFound = dynamicWait.until(ExpectedConditions.visibilityOf(findElement(element)));
        if (elementFound.isDisplayed()) {
            log.info(element + " found on the page");
            return "Pass";
        } else {
            log.info(element + " not found on the page");
            return "Fail";
        }
    }

    /**
     * Method name: waitForElementToBeVisible
     * Parameters: element as String and seconds as long
     * Return Type: WebElement
     * Exceptions: None
     * Objective: To wait defined seconds for the element to load
     */

    public String waitForElementToBeVisible(String element, long seconds) {
        WebDriverWait dynamicWait = new WebDriverWait(driver, ofSeconds(seconds));
        WebElement elementFound = dynamicWait.until(ExpectedConditions.visibilityOf(findElement(element)));
        if (elementFound.isDisplayed()) {
            log.info(element + " found on the page");
            return "Pass";
        } else {
            log.info(element + " not found on the page");
            return "Fail";
        }
    }

    /**
     * Method name: waitForElementToBeClickable
     * Parameters: element as String
     * Return Type: WebElement
     * Exceptions: None
     * Objective: To wait for the element to be clickable
     */

    public String waitForElementToBeClickable(String element) {
        WebDriverWait dynamicWait = new WebDriverWait(driver, ofSeconds(20));
        WebElement elementFound = dynamicWait.until(ExpectedConditions.elementToBeClickable(findElement(element)));
        if (elementFound.isDisplayed()) {
            log.info(element + " is clickable");
            return "Pass";
        } else {
            log.info(element + " is not clickable");
            return "Fail";
        }
    }

    /**
     * Method name: waitForElementPresence
     * Parameters: element as String
     * Return Type: WebElement
     * Exceptions: None
     * Objective: To wait 20 seconds for the element to visible
     */

    public String waitForPresenceOfElement(String element) {
        WebDriverWait dynamicWait = new WebDriverWait(driver, ofSeconds(20));
        List<WebElement> elementFounds;
        if (element.startsWith("//") || element.startsWith("(//"))
            elementFounds = dynamicWait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(element)));
        else
            elementFounds = dynamicWait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(getProperty(element))));
        if (elementFounds.size() > 0) {
            log.info(element + " found on the page");
            return "Pass";
        } else {
            log.info(element + " not found on the page");
            return "Fail";
        }
    }

    /**
     * Method name: waitForTextToBeVisible
     * Parameters: element as String and text as String
     * Return Type: WebElement
     * Exceptions: None
     * Objective: To wait 20 seconds for the element to visible
     */

    public String waitForTextToBeVisible(String element, String text) {
        WebDriverWait dynamicWait = new WebDriverWait(driver, ofSeconds(20));
        boolean result = dynamicWait.until(ExpectedConditions.textToBePresentInElement(findElement(element), text));
        if (result) {
            log.info(element + " found on the page");
            return "Pass";
        } else {
            log.info(element + " not found on the page");
            return "Fail";
        }
    }

    /**
     * Method name: waitForElementPresence
     * Parameters: element as String
     * Return Type: WebElement
     * Exceptions: None
     * Objective: To wait 20 seconds for the element to visible
     */

    public String waitForPresenceOfElement(String element, int seconds) {
        WebDriverWait dynamicWait = new WebDriverWait(driver, ofSeconds(seconds));
        List<WebElement> elementFounds;
        if (element.startsWith("//") || element.startsWith("(//"))
            elementFounds = dynamicWait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(element)));
        else
            elementFounds = dynamicWait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(getProperty(element))));
        if (elementFounds.size() > 0) {
            log.info(element + " found on the page");
            return "Pass";
        } else {
            log.info(element + " not found on the page");
            return "Fail";
        }
    }

    /**
     * Method name: pageContainsText
     * Parameters: element as String
     * Return Type: WebElement
     * Exceptions: None
     * Objective: To verify the existence of text on the page
     */

    public String pageContainsText(String text) {
        waitForElementToBeVisible("//*[contains(text(),'" + text + "')]");
        if (findElements("//*[contains(text(),'" + text + "')]").size() > 0) {
            log.info(text + " is displayed on the page");
            return "Pass";
        } else {
            log.info(text + " is not displayed on the page");
            return "Fail";
        }
    }

    /**
     * Method name: click
     * Parameters: element as String
     * Return Type: String
     * Exceptions: None
     * Objective: To click on the provided element
     */

    public String click(String element) {
        try {
            if (findElement(element).isEnabled() && findElements(element).size() > 0) {
                jsHelper(element, "scrollIntoView");
                findElement(element).click();
                waitUntilAngularReady();
                log.info("Clicked on " + element);
            } else {
                waitUntilAngularReady();
                jsExecutor.executeScript("arguments[0].click();", findElement(element));
                log.info("Clicked on " + element + " using javascript executor");
                waitUntilAngularReady();
            }
            return "Pass";
        } catch (Exception e) {
            log.fatal("Error found while clicking on the element: " + element);
            e.printStackTrace();
            return "Fail";
        }
    }

    /**
     * Method name: jsHelper
     * Parameters: element as String and action as String
     * Return Type: String
     * Exceptions: None
     * Objective: To execute any action using javascript executor
     */

    public String jsHelper(String element, String action) {
        WebElement webElement;
        if (element.startsWith("//")) {
            webElement = findElement(element);
        } else if (element.equals("")) {
            webElement = findElement("//html");
        } else {
            webElement = findElement(element);
        }
        switch (action.toLowerCase()) {
            case "click":
                jsExecutor.executeScript("arguments[0].click();", webElement);
                waitUntilAngularReady();
                return "Pass";
            case "scrollintoview":
                jsExecutor.executeScript("arguments[0].scrollIntoView(true);", webElement);
                return "Pass";
            case "scrolltotop":
                jsExecutor.executeScript("window.scrollTo(0,0);");
                return "Pass";
            default:
                log.info("Please enter a valid action type");
                return "Fail";
        }
    }

    /**
     * Method name: enterText
     * Parameters: element as String and text as String
     * Return Type: String
     * Exceptions: None
     * Objective: To enter a text in the provided element
     */

    public String enterText(String element, String text) {
        try {
            findElement(element).clear();
            findElement(element).sendKeys(text);
            log.info("Text entered in field " + element);
            return "Pass";
        } catch (Exception e) {
            log.fatal("Error found while entering the text in the field: " + element);
            e.printStackTrace();
            return "Fail";
        }
    }

    /**
     * Method name: getText
     * Parameters: element as String
     * Return Type: String
     * Exceptions: None
     * Objective: To get text from an element
     */

    public String getText(String element) {
        try {
            WebDriverWait dynamicWait = new WebDriverWait(driver, Duration.ofSeconds(20));
            WebElement newElement = dynamicWait.until(ExpectedConditions.visibilityOf(findElement(element)));
            log.info("Text: " + newElement.getText());
            return newElement.getText();
        } catch (Exception e) {
            log.fatal("Error found while getting the text from the field: " + element);
            e.printStackTrace();
            return "Fail";
        }
    }

    /**
     * Method name: selectByVisibleText
     * Parameters: element as String and visibleText as String
     * Return Type: String
     * Exceptions: None
     * Objective: To get text from an element
     */

    public String selectByVisibleText(String element, String visibleText) {
        try {
            Select select = new Select(findElement(element));
            select.selectByVisibleText(visibleText);
            return "Pass";
        } catch (Exception e) {
            log.fatal("Error found while selecting the visible text from the dropdown " + element);
            e.printStackTrace();
            return "Fail";
        }
    }

    /**
     * Method name: selectByIndex
     * Parameters: element as String and visibleText as String
     * Return Type: String
     * Exceptions: None
     * Objective: To get text from an element
     */

    public String selectByIndex(String element, int index) {
        try {
            Select select = new Select(findElement(element));
            select.selectByIndex(index);
            return "Pass";
        } catch (Exception e) {
            log.fatal("Error found while selecting the visible text from the dropdown " + element);
            e.printStackTrace();
            return "Fail";
        }
    }

    /**
     * Method name: performAction
     * Parameters: element as String and action as String
     * Return Type: String
     * Exceptions: None
     * Objective: To get text from an element
     */

    public String performAction(String element, String action) {
        try {
            switch (action.toLowerCase()) {
                case "click":
                    jsHelper(element, "scrollIntoView");
                    actions.moveToElement(findElement(element)).pause(ofSeconds(1)).click().build().perform();
                    return "Pass";
                case "move to and click":
                    jsHelper(element, "scrollIntoView");
                    waitAll(1000);
                    jsHelper(element, "click");
                    return "Pass";
                case "drag and drop":
                    String[] elements;
                    elements = element.split("-");
                    actions.clickAndHold(findElement(elements[0])).moveByOffset(5, 5).build().perform();
                    actions.moveToElement(findElement(elements[1])).release(findElement(elements[0])).build().perform();
                    return "Pass";
                default:
                    log.info("Please enter valid action");
                    return "Fail";
            }
        } catch (Exception e) {
            log.fatal("Error found while performing " + action + " on the field " + element);
            e.printStackTrace();
            return "Fail";
        }
    }


    ///////////////////////////////////////////////////////////////////////////////


    public void getAccessToken(String apiKeyType) {

        if (apiKeyType.equalsIgnoreCase("alipne_DNS")) {
            apiKey = "86D051A0-44EC-4375-B7D1-32B331B9D0DA:2769:132";
            baseUri = "http://alpine-dns-staging.apps.okd.mm-corp.net/";

        } else {
            apiKey = "e4d45cd8-ba4e-4ade-8f1c-c6b311f67444";
        }
    }

    /**
     * Method Name: getResponse
     * Parameters: None
     * Return Type: Response
     * Exceptions: None
     * Objective: To return Response
     **/

    public Response getResponse() {
        return response;
    }

    /**
     * Method Name: generateRandom
     * Parameters: digits as integer
     * Return Type: long
     * Exceptions: None
     * Objective: To generate random number on the basis of required digits
     **/

    public long generateRandom(int digits) {
        Random random = new Random();
        return (int) Math.pow(10, digits - 1) + random.nextInt((int) (Math.pow(10, digits) - 1));
    }

    /**
     * Method Name: generateRandomGuid
     * Parameters: None
     * Return Type: String
     * Exceptions: None
     * Objective: To generate a random GUID
     **/

    public String generateRandomGuid() {
        return UUID.randomUUID().toString();
    }

    /**
     * Method Name: getJsonPath
     * Parameters: None
     * Return Type: JsonPath
     * Exceptions: None
     * Objective: To get JSON body of the response payload
     **/

    public JsonPath getJsonPath() {
        return response.jsonPath();
    }

    /**
     * Method Name: validateStatusCode
     * Parameters: apiUrl as String, body as String, statusCode as int & methodType as String
     * Return Type: None
     * Exceptions: None
     * Objective: To validate the expected status code coming from api response
     **/

    public void validateStatusCode(String apiUrl, String body, int statusCode, String methodType) {
        setResponse(apiUrl, methodType, body);
        log.info("Actual Status Code : " + response.statusCode() + ", Expected Status Code : " + statusCode);
        response.then().statusCode(statusCode);
    }

    /**
     * Method Name: getStatusCode
     * Parameters: apiUrl as String, body as String, statusCode as int & methodType as String
     * Return Type: Integer
     * Exceptions: None
     * Objective: To get the statuscode from response
     **/

    public Integer getStatusCode(String apiUrl, String body, String methodType) {
        setResponse(apiUrl, methodType, body);
        log.info("Actual Status Code : " + response.statusCode());
        return response.statusCode();
    }

    public void validateStatusCodeFromResponse(int statusCode) {
        log.info("Actual Status Code : " + response.statusCode() + ", Expected Status Code : " + statusCode);
        response.then().statusCode(statusCode);
    }

    /**
     * Method Name: validateResponseMessage
     * Parameters: apiUrl as String, body as String, expectedMessage as String & methodType as String
     * Return Type: None
     * Exceptions: None
     * Objective: To validate the expected response message coming from api response
     **/

    public void validateResponseMessage(String apiUrl, String body, String expectedMessage, String methodType) {
        setResponse(apiUrl, methodType, body);
//        log.info("Actual Message : " + response.asString() + ", Expected Message : " + expectedMessage);
        Assert.assertTrue(expectedMessage + " not found in the response", response.asString().contains(expectedMessage));
    }

    public void validateResponseMessage(String expectedMessage) {
//        log.info("Actual Message : " + response.asString() + ", Expected Message : " + expectedMessage);
        Assert.assertTrue(expectedMessage + " not found in the response", response.asString().contains(expectedMessage));
    }

    /**
     * Method Name: validateKeyValueFromResponse
     * Parameters: apiUrl as String, keyName as String, keyValue as String, methodType as String & body as String
     * Return Type: None
     * Exceptions: None
     * Objective: To validate any String value of a parameter coming in the response
     **/

    public void validateKeyValueFromResponse(String apiUrl, String keyName, String keyValue, String methodType, String body) {
        setResponse(apiUrl, methodType, body);
        JsonPath jsonPath = getJsonPath();
        log.info("Actual Parameter Value: " + jsonPath.get(keyName) + ", Expected Key Value: " + keyValue);
        Assert.assertEquals(jsonPath.get(keyName), keyValue);
    }

    public void validateKeyValueFromResponse(String keyName, String keyValue) {
        JsonPath jsonPath = getJsonPath();
        log.info("Response found successfully");
        log.info("Actual Parameter Value: " + jsonPath.get(keyName) + ", Expected Key Value: " + keyValue);
        Assert.assertEquals(keyValue, jsonPath.get(keyName).toString());
        // Assert.assertEquals(jsonPath.get(keyName), keyValue);
    }


    /**
     * Method Name: validateKeyContainValueFromResponse
     * Parameters: apiUrl as String, keyName as String, keyValue as String, methodType as String & body as String
     * Return Type: None
     * Exceptions: None
     * Objective: To validate any String value of a parameter contains value provided in the response
     **/

    public void validateKeyContainValueFromResponse(String apiUrl, String keyName, String keyValue, String methodType, String body) {
        setResponse(apiUrl, methodType, body);
        JsonPath jsonPath = getJsonPath();
//        log.info("Actual Parameter Value: " + jsonPath.get(keyName) + ", Expected Key Value: " + keyValue);
        Assert.assertTrue(jsonPath.get(keyName).toString().contains(keyValue));
    }

    /**
     * Method Name: validateKeyContainValuesFromResponse
     * Parameters: apiUrl as String, keyName as String, keyValues as List of String, methodType as String & body as String
     * Return Type: None
     * Exceptions: None
     * Objective: To validate any String value of a parameter contains list of values provided in the response
     **/

    public void validateKeyContainValuesFromResponse(String apiUrl, String keyName, List<String> keyValues, String methodType, String body) {
        setResponse(apiUrl, methodType, body);
        JsonPath jsonPath = getJsonPath();
        log.info("Actual Parameter Value: " + jsonPath.get(keyName));
        for (String value : keyValues) {
//            log.info("Expected Key Value: " + value);
            Assert.assertTrue(jsonPath.get(keyName).toString().contains(value));
        }
    }

    /**
     * Method Name: validateKeyValueFromResponse
     * Parameters: apiUrl as String, keyName as String, keyValue as int, methodType as String & body as JSONObject
     * Return Type: None
     * Exceptions: None
     * Objective: To validate any int value of a parameter coming in the response
     **/

    public void validateKeyValueFromResponse(String apiUrl, String keyName, int keyValue, String methodType, String body) {
        setResponse(apiUrl, methodType, body);
        log.info("Actual Parameter Value: " + getJsonPath().get(keyName) + ", Expected Key Value: " + keyValue);
        Assert.assertEquals(getJsonPath().getInt(keyName), keyValue);
    }

    /**
     * Method Name: validateKeyValueFromResponse
     * Parameters: apiUrl as String, keyName as String, keyValue as boolean, methodType as String & body as JSONObject
     * Return Type: None
     * Exceptions: None
     * Objective: To validate any int value of a parameter coming in the response
     **/

    public void validateKeyValueFromResponse(String apiUrl, String keyName, boolean keyValue, String methodType, String body) {
        setResponse(apiUrl, methodType, body);
        log.info("Actual Parameter Value: " + getJsonPath().get(keyName) + ", Expected Key Value: " + keyValue);
        Assert.assertEquals(getJsonPath().getBoolean(keyName), keyValue);
    }


    /**
     * Method Name: validateKeyValuesFromResponse
     * Parameters: apiUrl as String, keyName as String, keyValue as int, methodType as String & body as String
     * Return Type: None
     * Exceptions: None
     * Objective: To validate whether an int value is coming in a list of values corresponding to the parameter coming in the response
     **/

    public void validateKeyValuesFromResponse(String apiUrl, String keyName, int keyValue, String methodType, String body) {
        setResponse(apiUrl, methodType, body);
        log.info("Actual Parameter Value: " + getJsonPath().get(keyName) + ", Expected Key Value: " + keyValue);
        MatcherAssert.assertThat(getJsonPath().get(keyName), hasItem(keyValue));
    }

    /**
     * Method Name: validateKeyValuesFromResponse
     * Parameters: apiUrl as String, keyName as String, keyValue as String, methodType as String & body as String
     * Return Type: None
     * Exceptions: None
     * Objective: To validate whether an String value is coming in a list of values corresponding to the parameter coming in the response
     **/

    public void validateKeyValuesFromResponse(String apiUrl, String keyName, String keyValue, String methodType, String body) {
        setResponse(apiUrl, methodType, body);
//        log.info("Actual Parameter Value: " + getJsonPath().get(keyName) + ", Expected Key Value: " + keyValue);
        MatcherAssert.assertThat(getJsonPath().get(keyName), hasItem(keyValue));
    }

    /**
     * Method Name: validateKeyValuesFromResponse
     * Parameters: apiUrl as String, keyName as String, keyValue as boolean, methodType as String & body as String
     * Return Type: None
     * Exceptions: None
     * Objective: To validate whether an boolean value is coming in a list of values corresponding to the parameter coming in the response
     **/

    public void validateKeyValuesFromResponse(String apiUrl, String keyName, boolean keyValue, String methodType, String body) {
        setResponse(apiUrl, methodType, body);
        log.info("Actual Parameter Value: " + getJsonPath().get(keyName) + ", Expected Key Value: " + keyValue);
        MatcherAssert.assertThat(getJsonPath().get(keyName), hasItem(keyValue));
    }

    /**
     * Method Name: validateKeyValuesFromResponse
     * Parameters: apiUrl as String, keyName as String, keyValue as boolean, methodType as String & body as String
     * Return Type: None
     * Exceptions: None
     * Objective: To validate whether an boolean value is coming in a list of values corresponding to the parameter coming in the response
     **/

    public void validateKeyValuesFromResponse(String apiUrl, String keyName, List<String> keyValues, String methodType, String body) {
        setResponse(apiUrl, methodType, body);
//        log.info("Actual Parameter Value: " + getJsonPath().get(keyName) + ", Expected Key Value: " + keyValues);
        MatcherAssert.assertThat(getJsonPath().get(keyName), hasItem(keyValues));
    }

    /**
     * Method Name: getAllValuesFromResponse
     * Parameters: apiUrl as String, body as String, keyName as String & methodType as String
     * Return Type: None
     * Exceptions: None
     * Objective: To get list of String values of a parameter coming in the response
     **/

    public List<String> getAllValuesFromResponse(String apiUrl, String body, String keyName, String methodType) {
        setResponse(apiUrl, methodType, body);
//        log.info("List of all the values from response: " + getJsonPath().get(keyName));
        return getJsonPath().getList(keyName);
    }

    /**
     * Method Name: getIntValueFromResponse
     * Parameters: apiUrl as String, body as String, keyName as String & methodType as String
     * Return Type: Object
     * Exceptions: None
     * Objective: To get single String value of a parameter coming in the response
     **/

    public Object getValueFromResponse(String apiUrl, String body, String keyName, String methodType) {
        setResponse(apiUrl, methodType, body);
//        log.info("The value from response: " + getJsonPath().get(keyName));
        return getJsonPath().get(keyName);
    }


    public String getValueFromResponseInString(String apiUrl, String body, String keyName, String methodType) {
        setResponse(apiUrl, methodType, body);
        log.info("Response found successfully");
        log.info("The values from response: " + getJsonPath().get(keyName));
        return getJsonPath().get(keyName);
    }

    public String getValueFromResponseInString(String keyName) {
        log.info("Response found successfully");
        log.info("The values from response: " + getJsonPath().get(keyName));
        return getJsonPath().get(keyName);

    }

    /**
     * Method Name: setResponse
     * Parameters: apiUrl as String, methodType as String & body as String
     * Return Type: None
     * Exceptions: None
     * Objective: To set response after providing the JSON payload to API
     **/

    public void setResponse(String apiUrl, String methodType, String body) {
        switch (methodType.toUpperCase()) {
            case "GET":
                response = RestAssured.given()
                        .header("ALPINE-API-KEY", apiKey)
                        .get(apiUrl);
                break;
            case "PUT":
                response = RestAssured.given()
                        .header("ALPINE-API-KEY", apiKey)
                        .body(body).with().contentType(ContentType.JSON).put(apiUrl);
                break;
            case "POST":
                response = RestAssured.given()
                        .header("ALPINE-API-KEY", apiKey)
                        .body(body).with().contentType(ContentType.JSON).post(apiUrl);
                break;
            case "DELETE":
                response = RestAssured.given()
                        .header("ALPINE-API-KEY", apiKey)
                        .body(body).with().contentType(ContentType.JSON).delete(apiUrl);
                break;
            case "PATCH":
                response = RestAssured.given()
                        .header("ALPINE-API-KEY", apiKey)
                        .body(body).with().contentType(ContentType.JSON).patch(apiUrl);
                break;
            default:
                log.info("Please enter valid method type. Entered Method Type: " + methodType);
                throw new IllegalArgumentException();
        }
    }

    /**
     * Method Name: validateMissingHeaderResponseMessage
     * Parameters: apiUrl as String, headerName as String & expectedMessage as String
     * Return Type: None
     * Exceptions: None
     * Objective: To validate whether a header is missing in the GET request
     **/

    public void validateMissingHeaderResponseMessage(String apiUrl, String headerName, String expectedMessage) {
        setResponse(apiUrl, "GET", "");
        response = getResponse();
        log.info("Actual Header Value: " + response.getHeader(headerName) + ", Expected Header Value: " + headerName);
        Assert.assertEquals(response.asString(), expectedMessage);
    }

    /**
     * Method Name: validateResponseTime
     * Parameters: apiName as String, apiUrl as String, body as String, benchmarkResponseTime as long & methodType as String
     * Return Type: None
     * Exceptions: None
     * Objective: To validate the response time for the API on the basis on benchmark response time defined.
     **/

    public String validateResponseTime(String apiName, String apiUrl, String body, String methodType) {
        double[] iteration = new double[3];
        for (int i = 0; i < 3; i++) {
            setResponse(apiUrl, methodType, body);
//            validateStatusCode(apiUrl,body,status,methodType);
            iteration[i] = response.time();
        }
        double avg = Math.round(((iteration[0] + iteration[1] + iteration[2]) / 3) * 100) / 100.0;
        String status = (avg < BENCHMARK_RESPONSE_TIME) ? "Pass" : "Fail";
        log.info("Response Time : " + iteration[0] + "ms, " + iteration[1] + "ms, " + iteration[2] + "ms");
      xlUtil.writeToExcel(apiName, BENCHMARK_RESPONSE_TIME, iteration, avg, status);
//        Assert.assertEquals("Pass", status);
        return status;
    }

    public String validateResponseTime(String apiName, String apiUrl, String secondpart, String body, String methodType, List<String> idlist) {
        double[] iteration = new double[3];

        for (int i = 0; i < 3; i++) {
            String url = apiUrl + idlist.get(i);
            if (!secondpart.isEmpty()) {
                url = url + "/" + secondpart;
            }
            setResponse(apiUrl, methodType, body);
//            validateStatusCode(url, body, 200, methodType);
            iteration[i] = response.time();
        }
        double avg = Math.round(((iteration[0] + iteration[1] + iteration[2]) / 3) * 100) / 100.0;
        String status = (avg < BENCHMARK_RESPONSE_TIME) ? "Pass" : "Fail";
        log.info("Response Time : " + iteration[0] + "ms, " + iteration[1] + "ms, " + iteration[2] + "ms");

//        xlUtil.writeToExcel(apiName, BENCHMARK_RESPONSE_TIME, iteration, avg, status);
//        Assert.assertEquals("Pass", status);
        return status;
    }

    public String getCurrentDate(String format) {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern(format));
    }
}
