package library;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesUtil {

    static Properties properties;
    static String propertiesFilePath = System.getProperty("user.dir") + "\\src\\test\\resources\\Function.properties";

    static {
        try {
            properties = new Properties();
            properties.load(new FileInputStream(propertiesFilePath));
        } catch (IOException e) {
            System.out.println("Error found: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Method name: setProperty
     * Parameters: propertyName as String and propertyValue as String
     * Return Type: None
     * Objective: To store new property value to Function.properties file
     **/

    public static void setProperty(String propertyName, String propertyValue) {
        properties.setProperty(propertyName, propertyValue);
        try {
            FileOutputStream outputStream = new FileOutputStream(propertiesFilePath);
            properties.store(outputStream, "Storing new value for " + propertyName);
        } catch (Exception e) {
            System.out.println("Error found: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Method name: getProperty
     * Parameters: propertyName as String
     * Return Type: String
     * Objective: To find the property value from Function.properties file
     **/

    public static String getProperty(String propertyName) {
        return properties.getProperty(propertyName);
    }
}
