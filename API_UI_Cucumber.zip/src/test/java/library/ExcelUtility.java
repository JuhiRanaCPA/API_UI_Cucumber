package library;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class ExcelUtility {
    private static int rowNum = 0;
    private static XSSFWorkbook workbook = null;
    private static XSSFSheet sheet = null;
    private static String FILE_NAME = "";
    private final String SHEET_NAME = "Performance Sheet";

    /**
     * Method Name: ExcelUtility
     * Parameters: None
     * Return Type: constructor
     * Exceptions: None
     * Objective: To initialize the excel file specific to project
     **/

    public ExcelUtility(String projectName) {
        FILE_NAME = System.getProperty("user.dir") + "\\src\\test\\resources\\" + projectName + " API Performance Report.xlsx";
        System.out.println("Output =" + FILE_NAME);
    }

    /**
     * Method Name: initializePerformanceSheet
     * Parameters: None
     * Return Type: None
     * Exceptions: None
     * Objective: To initialize the performance sheet and its columns with header names
     **/

    public void initializePerformanceSheet() {
        XSSFFont cellFont;
        XSSFCellStyle cellStyle;
        XSSFRow row;
        workbook = new XSSFWorkbook();

        if (workbook.getNumberOfSheets() == 0) {
            sheet = workbook.createSheet(SHEET_NAME);
            rowNum = sheet.getLastRowNum();
            if (rowNum == 0) {
                Object[][] data = {{"API Name", "Benchmark Time", "Execution Time 1", "Execution Time 2", "Execution Time 3",
                        "Avg. Response Time", "Performance Status"}};
                for (Object[] rowData : data) {
                    row = sheet.createRow(rowNum);
                    cellFont = workbook.createFont();
                    cellFont.setBold(true);
                    cellStyle = workbook.createCellStyle();
                    cellStyle.setFont(cellFont);
                    int colNum = 0;
                    for (Object field : rowData) {
                        Cell cell = row.createCell(colNum++);
                        cell.setCellValue((String) field);
                        cell.setCellStyle(cellStyle);
                    }
                }
                rowNum = rowNum + 1;
            }
        } else {
            sheet = workbook.getSheet(SHEET_NAME);
            System.out.println("Performance Sheet already present");
        }
        try (FileOutputStream outputStream = new FileOutputStream(FILE_NAME)) {
            workbook.write(outputStream);
            workbook.close();
        } catch (Exception e) {
            System.out.println("Exception found: " + e.getLocalizedMessage());
            e.printStackTrace();
        }
    }

    /**
     * Method Name: readFromExcel
     * Parameters: None
     * Return Type: None
     * Exceptions: None
     * Objective: To read the refman file
     **/

//    public void readFromExcel() {
//        try {
//            FileInputStream excelFile = new FileInputStream(new File(FILE_NAME));
//            workbook = new XSSFWorkbook(excelFile);
//            sheet = workbook.getSheetAt(0);
//            Iterator<Row> iterator = sheet.iterator();
//            while (iterator.hasNext()) {
//                Row currentRow = iterator.next();
//                Iterator<Cell> cellIterator = currentRow.iterator();
//                while (cellIterator.hasNext()) {
//                    Cell currentCell = cellIterator.next();
//                    if (currentCell.getCellType() == CellType.STRING) {
//                        System.out.print(currentCell.getStringCellValue() + "--");
//                    } else if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
//                        System.out.print(currentCell.getNumericCellValue() + "--");
//                    }
//                }
//                System.out.println();
//            }
//            workbook.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    /**
     * Method Name: writeToExcel
     * Parameters: None
     * Return Type: None
     * Exceptions: None
     * Objective: To write the performance data to refman file
     **/

    public void writeToExcel(String apiName, long benchmarkData, double[] iteration, double avg, String status) {
//        File file = new File(FILE_NAME);
//        if (file.exists() == false) {
        try (FileInputStream inputStream = new FileInputStream(FILE_NAME)) {
            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheetAt(0);
        } catch (Exception e1) {
            e1.printStackTrace();
        }

        Object[][] data = {{apiName, benchmarkData, iteration[0], iteration[1], iteration[2], avg, status}};
        rowNum = sheet.getLastRowNum();

        XSSFFont redFont = workbook.createFont();
        redFont.setColor(IndexedColors.RED.getIndex());

        XSSFCellStyle redStyle = workbook.createCellStyle();
        //     redStyle.setFillBackgroundColor(IndexedColors.BLUE.getIndex());
        redStyle.setFont(redFont);

        for (Object[] rowData : data) {
            Row row = sheet.createRow(++rowNum);
            int colNum = 0;
            for (Object field : rowData) {
                Cell cell = row.createCell(colNum++);
                if (status.equals("Fail"))
                    cell.setCellStyle(redStyle);
                if (field instanceof String) {
                    cell.setCellValue((String) field);
                } else if (field instanceof Integer) {
                    cell.setCellValue((Integer) field);
                } else if (field instanceof Long) {
                    cell.setCellValue((Long) field);
                } else if (field instanceof Double) {
                    cell.setCellValue((Double) field);
                }
                if (benchmarkData < avg)
                    cell.setCellStyle(redStyle);
            }

        }
        rowNum = rowNum + 1;
        try (FileOutputStream outputStream = new FileOutputStream(FILE_NAME)) {
            workbook.write(outputStream);
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
