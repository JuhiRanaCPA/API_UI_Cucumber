package requestBody;

import io.cucumber.datatable.DataTable;
import library.Functions;

import java.util.List;
import java.util.Random;

public class RequestBody extends Functions {
    private String commonName = "dnsmigrationtest1.net";
    private String csr = "-----BEGIN CERTIFICATE REQUEST-----\\nMIIC7zCCAdcCAQAwgakxCzAJBgNVBAYTAlVTMQ4wDAYDVQQIDAVJZGFobzEOMAwG\\nA1UEBwwFQm9pc2UxGTAXBgNVBAoMEE1hcmtNb25pdG9yIEluYy4xFDASBgNVBAsM\\nC0VuZ2luZWVyaW5nMRgwFgYDVQQDDA9tYXJrbW9uaXRvci5jb20xLzAtBgkqhkiG\\n9w0BCQEWIHRlc3R5Lm1jdGVzdGZhY2VAbWFya21vbml0b3IuY29tMIIBIjANBgkq\\nhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAndrfVoIAtmr4ZJ/0weQK6cCiMYTA1SQY\\nHu07WFlr3ITgm4+Mx0W1T3jP9VzYu+RndTXukoaWP7zheLKreW5NnNHddic7FAJ+\\n5H5z8JSL8A8iNrjO13LfhPKWq3BA2goE+3CfIhzpzVuaxOuScwbLlU+kAFTyltrT\\n0E6OohU7wAemPbURwPaaAIK714nz5upfMvf0TqtmaQbTtDrCGTBMnu+xkdWmpFOq\\nA6Kf2rbkzfJvxYxqCfnKeSZNQFik4cyEUIxTmmksErJgBpoWMYJfV7qQ2/VhZKPt\\ngrjUjksJL2MXS6/iDcZgMotUEPcpUil0GRyiqds1m8acFg9TReJ3VwIDAQABoAAw\\nDQYJKoZIhvcNAQELBQADggEBAI6Zxmuiop81nTUCOHpeO+pkOxMVPUUWBE7nqX9e\\nA2k+fNm7cBfdLxYLFc5WUu+4LswVqPfHFfX76tzcMg5CmVdNNz7wlsfGHlGi84z5\\nCoKZCTmsf5+TM33DPmqf6jTArTrszeKxcxSC09yFoj4Sin1w1KYR3N11rRNlCSL8\\nY9Rn4a0e/jymCapMZgmKwrgauHSyHZjuIXtzBZEURyenKw/2Wi7JtigulmZTNgXr\\n9kIgfCzLqrvvRxwDxE3+Q23+3mzeDsFajjX/22BsOaZrz5c/N5dKt4GWdgvI5eqK\\nXS9XbqCfEIvfRlWfq0Nm8n/HyFNRWEP261HcQOLyvwKRF9A=-----END CERTIFICATE REQUEST-----\\n";
    private String serverPlatform = "DEFAULT";
    private String signatureHash = "SHA_256";
    private String accountId = "35";
    private String dcvMethod = "DNS_TXT_TOKEN";
    private String firstName = "firstName_1";
    private String lastName = "lastName_1";
    private String jobTitle = "Mr";
    private String email = "abcffft@example.com";
    private String phone = "+1.222 222 2222";
    private String provider = "DIGICERT";
    private String type = "ORGANIZATION_CONTACT";
    private String address1 = "123 Mamoura bwww";
    private String city = "Boise";
    private String state = "Idaho";
    private String country = "US";
    private String zipcode = "83709";
    private String active = "true";
    private String validations_type = "OV";
    private String validations_name = "ov";
    private String contact_type = "ORGANIZATION_CONTACT";
    private String daysValid = "365";
    private String expirationType = "DAYS";
    private String comments = "This is a test order";
    private String certType = "SSL_DV_GEOTRUST";
    private String locale = "en";
    private String validation_type = "OV";
    private String status = "active";
    private String api_Type = "NONE";
    private String template = "true";
    private String zoneType = "PRIMARY";
    private String expires = "2021-12-04T16:27:32.143+0000";
    private String recordsData = "pankag.neog@clarivate.com";
    private String recordsTtl = "86400";
    private String recordsName = "ns1.markmonitor.com";
    private String recordsRefresh = "86400";
    private String recordsRetry = "3600";
    private String recordsSerial = "2020120401";
    private String recordsOrmid = "1234";
    private String recordsType = "SOA";
    private String name = "automation_api_DNS.com";
    private String data = "128 issue \\\"jeff-new2.com\\\"";
    private String recordtype = "CAA";
    private String ttl = "4800";
    private String validations_description = "validation description";

    public String cert_StrBody(DataTable table) {

        List<List<String>> rows = table.asLists(String.class);
        for (List<String> columns : rows) {
            switch (columns.get(0)) {
                case "accountId":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        accountId = "";
                    } else {
                        accountId = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "commonName":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        commonName = "";
                    } else {
                        commonName = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "csr":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        csr = "";
                    } else {
                        csr = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "serverPlatform":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        serverPlatform = "";
                    } else {
                        serverPlatform = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;

                case "signatureHash":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        signatureHash = "";
                    } else {
                        signatureHash = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;

                case "dcvMethod":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        dcvMethod = "";
                    } else {
                        dcvMethod = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;

                default:
                    log.info("Menu item not found");
                    statusList.add("Fail");
                    break;

            }
        }
        strBody = "{\n" +
                "        \"commonName\": \"" + commonName + "\",\n" +
                "        \n" +
                "        \"csr\": \"" + csr + "\",\n" +
                "        \"serverPlatform\": \"" + serverPlatform + "\",\n" +
                "        \"signatureHash\": \"" + signatureHash + "\",\n" +
                "        \"accountId\": " + accountId + ",\n" +
                "        \"dcvMethod\": \"" + dcvMethod + "\"\n" +
                "    }";
        return strBody;
    }

    public String cert_StrBody(String element, String elevalue) {
        switch (element) {
            case "accountId":
                if (elevalue.equalsIgnoreCase("")) {
                    accountId = "";
                } else {
                    accountId = elevalue;
                }
                statusList.add("Pass");
                break;
            case "commonName":
                if (elevalue.equalsIgnoreCase("")) {
                    commonName = "";
                } else {
                    commonName = elevalue;
                }
                statusList.add("Pass");
                break;
            case "csr":
                if (elevalue.equalsIgnoreCase("")) {
                    csr = "";
                } else {
                    csr = elevalue;
                }
                statusList.add("Pass");
                break;
            case "serverPlatform":
                if (elevalue.equalsIgnoreCase("")) {
                    serverPlatform = "";
                } else {
                    serverPlatform = elevalue;
                }
                statusList.add("Pass");
                break;

            case "signatureHash":
                if (elevalue.equalsIgnoreCase("")) {
                    signatureHash = "";
                } else {
                    signatureHash = elevalue;
                }
                statusList.add("Pass");
                break;

            case "dcvMethod":
                if (elevalue.equalsIgnoreCase("")) {
                    dcvMethod = "";
                } else {
                    dcvMethod = elevalue;
                }
                statusList.add("Pass");
                break;

            default:
                log.info("Menu item not found");
                statusList.add("Fail");
                break;


        }
        strBody = "{\n" +
                "        \"commonName\": \"" + commonName + "\",\n" +
                "        \n" +
                "        \"csr\": \"" + csr + "\",\n" +
                "        \"serverPlatform\": \"" + serverPlatform + "\",\n" +
                "        \"signatureHash\": \"" + signatureHash + "\",\n" +
                "        \"accountId\": " + accountId + ",\n" +
                "        \"dcvMethod\": \"" + dcvMethod + "\"\n" +
                "    }";
        return strBody;
    }

    public String contact_StrBody(DataTable table) {

        List<List<String>> rows = table.asLists(String.class);
        String contactstring = "";
        for (List<String> columns : rows) {
            switch (columns.get(0)) {
                case "phone":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        phone = "";
                    } else {
                        phone = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "accountId":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        accountId = "";
                    } else {
                        accountId = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;

                case "firstName":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        firstName = "";
                    } else {
                        firstName = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "lastName":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        lastName = "";
                    } else {
                        lastName = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "jobTitle":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        jobTitle = "";
                    } else {
                        jobTitle = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "email":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        email = "";
                    } else {
                        email = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "type":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        type = "";
                    } else {
                        type = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "provider":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        provider = "";
                    } else {
                        provider = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;

                default:
                    log.info("Menu item not found");
                    statusList.add("Fail");
                    break;
            }
            contactstring = "{\n" +
                    "            \"firstName\": \"" + firstName + "\",\n" +
                    "            \"lastName\": \"" + lastName + "\",\n" +
                    "            \"jobTitle\": \"" + jobTitle + "\",\n" +
                    "            \"email\": \"" + email + "\",\n" +
                    "            \"phone\": \"" + phone + "\",\n" +
                    "            \"accountId\": " + accountId + ",\n" +
                    "            \"provider\": \"" + provider + "\",\n" +
                    "            \"contactTypes\": [\n" +
                    "                {\n" +
                    "                    \"type\": \"" + type + "\"\n" +
                    "                }\n" +
                    "            ]\n" +
                    "        }";
        }
        assertCheck("Fail", statusList);
        return contactstring;
    }

    public String contact_StrBody(String element, String elevalue) {

        String contactstring = "";

        switch (element) {
            case "phone":
                if (elevalue.equalsIgnoreCase("")) {
                    phone = "";
                } else {
                    phone = elevalue;
                }
                statusList.add("Pass");
                break;
            case "accountId":
                if (elevalue.equalsIgnoreCase("")) {
                    accountId = "";
                } else {
                    accountId = elevalue;
                }
                statusList.add("Pass");
                break;

            case "firstName":
                if (elevalue.equalsIgnoreCase("")) {
                    firstName = "";
                } else {
                    firstName = elevalue;
                }
                statusList.add("Pass");
                break;
            case "lastName":
                if (elevalue.equalsIgnoreCase("")) {
                    lastName = "";
                } else {
                    lastName = elevalue;
                }
                statusList.add("Pass");
                break;
            case "jobTitle":
                if (elevalue.equalsIgnoreCase("")) {
                    jobTitle = "";
                } else {
                    jobTitle = elevalue;
                }
                statusList.add("Pass");
                break;
            case "email":
                if (elevalue.equalsIgnoreCase("")) {
                    email = "";
                } else {
                    email = elevalue;
                }
                statusList.add("Pass");
                break;
            case "type":
                if (elevalue.equalsIgnoreCase("")) {
                    type = "";
                } else {
                    type = elevalue;
                }
                statusList.add("Pass");
                break;
            case "provider":
                if (elevalue.equalsIgnoreCase("")) {
                    provider = "";
                } else {
                    provider = elevalue;
                }
                statusList.add("Pass");
                break;

            default:
                log.info("Menu item not found");
                statusList.add("Fail");
                break;
        }
        contactstring = "{\n" +
                "            \"firstName\": \"" + firstName + "\",\n" +
                "            \"lastName\": \"" + lastName + "\",\n" +
                "            \"jobTitle\": \"" + jobTitle + "\",\n" +
                "            \"email\": \"" + email + "\",\n" +
                "            \"phone\": \"" + phone + "\",\n" +
                "            \"accountId\": " + accountId + ",\n" +
                "            \"provider\": \"" + provider + "\",\n" +
                "            \"contactTypes\": [\n" +
                "                {\n" +
                "                    \"type\": \"" + type + "\"\n" +
                "                }\n" +
                "            ]\n" +
                "        }";
        assertCheck("Fail", statusList);
        return contactstring;
    }

    public String organization_StrBody(DataTable table) {
        List<List<String>> rows = table.asLists(String.class);
        orgName = "";
        for (List<String> columns : rows) {
            switch (columns.get(0)) {
                case "name":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        orgName = "";
                    } else if (columns.get(1).equals("##################")) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        orgName = "Automation_" + getCurrentDate("dd_mm_yyyy_hh_mm_ss");
                    } else {
                        orgName = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "address1":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        address1 = "";
                    } else {
                        address1 = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "city":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        city = "";
                    } else {
                        city = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "state":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        state = "";
                    } else {
                        state = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "country":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        country = "";
                    } else {
                        country = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "zipcode":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        zipcode = "";
                    } else {
                        zipcode = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "phone":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        phone = "";
                    } else {
                        phone = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "accountId":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        accountId = "";
                    } else {
                        accountId = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "active":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        active = "";
                    } else {
                        active = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "provider":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        provider = "";
                    } else {
                        provider = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "validations_type":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        validations_type = "";
                    } else {
                        validations_type = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "validations_name":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        validations_name = "";
                    } else {
                        validations_name = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "validations_description":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        validations_description = "";
                    } else {
                        validations_description = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                default:
                    log.info("Menu item not found");
                    statusList.add("Fail");
                    break;
            }

        }

        String strBody = "{\n" +
                "    \"name\": \"" + orgName + "\",\n" +
                "    \"address1\": \"" + address1 + "\",\n" +
                "    \"city\": \"" + city + "\",\n" +
                "    \"state\": \"" + state + "\",\n" +
                "    \"country\": \"" + country + "\",\n" +
                "    \"zipcode\": \"" + zipcode + "\",\n" +
                "    \"phone\": \"" + phone + "\",\n" +
                "    \"accountId\": " + accountId + ",\n" +
                "    \"active\": " + active + ",\n" +
                "    \"contacts\": [\n" + contactString +
                "    ],\n" +
                "    \"provider\": \"" + provider + "\",\n" +
                "    \"validations\": [\n" +
                "        {\n" +
                "            \"type\": \"" + validations_type + "\",\n" +
                "            \"name\": \"" + validations_name + "\",\n" +
                "            \"description\": \"" + validations_description + "\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
        assertCheck("Fail", statusList);
        return strBody;
    }

    public String organization_StrBody(String element, String elevalue)  {
try {
//        orgName = "Automation_" + (99900000 + new Random().nextInt(10000));
    Thread.sleep(1000);
    orgName = "Automation_" + getCurrentDate("dd_mm_yyyy_hh_mm_ss");
    switch (element) {
        case "name":
            if (elevalue.equalsIgnoreCase("")) {
                orgName = "";
            } else {
                orgName = elevalue;
            }
            statusList.add("Pass");
            break;
        case "address1":
            if (elevalue.equalsIgnoreCase("")) {
                address1 = "";
            } else {
                address1 = elevalue;
            }
            statusList.add("Pass");
            break;
        case "city":
            if (elevalue.equalsIgnoreCase("")) {
                city = "";
            } else {
                city = elevalue;
            }
            statusList.add("Pass");
            break;
        case "state":
            if (elevalue.equalsIgnoreCase("")) {
                state = "";
            } else {
                state = elevalue;
            }
            statusList.add("Pass");
            break;
        case "country":
            if (elevalue.equalsIgnoreCase("")) {
                country = "";
            } else {
                country = elevalue;
            }
            statusList.add("Pass");
            break;
        case "zipcode":
            if (elevalue.equalsIgnoreCase("")) {
                zipcode = "";
            } else {
                zipcode = elevalue;
            }
            statusList.add("Pass");
            break;
        case "phone":
            if (elevalue.equalsIgnoreCase("")) {
                phone = "";
            } else {
                phone = elevalue;
            }
            statusList.add("Pass");
            break;
        case "accountId":
            if (elevalue.equalsIgnoreCase("")) {
                accountId = "";
            } else {
                accountId = elevalue;
            }
            statusList.add("Pass");
            break;
        case "active":
            if (elevalue.equalsIgnoreCase("")) {
                active = "";
            } else {
                active = elevalue;
            }
            statusList.add("Pass");
            break;
        case "provider":
            if (elevalue.equalsIgnoreCase("")) {
                provider = "";
            } else {
                provider = elevalue;
            }
            statusList.add("Pass");
            break;
        case "validations_type":
            if (elevalue.equalsIgnoreCase("")) {
                validations_type = "";
            } else {
                validations_type = elevalue;
            }
            statusList.add("Pass");
            break;
        case "validations_name":
            if (elevalue.equalsIgnoreCase("")) {
                validations_name = "";
            } else {
                validations_name = elevalue;
            }
            statusList.add("Pass");
            break;
        case "validations_description":
            if (elevalue.equalsIgnoreCase("")) {
                validations_description = "";
            } else {
                validations_description = elevalue;
            }
            statusList.add("Pass");
            break;
        default:
            log.info("Menu item not found");
            statusList.add("Fail");
            break;


    }
    String strBody = "{\n" +
            "    \"name\": \"" + orgName + "\",\n" +
            "    \"address1\": \"" + address1 + "\",\n" +
            "    \"city\": \"" + city + "\",\n" +
            "    \"state\": \"" + state + "\",\n" +
            "    \"country\": \"" + country + "\",\n" +
            "    \"zipcode\": \"" + zipcode + "\",\n" +
            "    \"phone\": \"" + phone + "\",\n" +
            "    \"accountId\": " + accountId + ",\n" +
            "    \"active\": " + active + ",\n" +
            "    \"contacts\": [\n" + contactString +
            "    ],\n" +
            "    \"provider\": \"" + provider + "\",\n" +
            "    \"validations\": [\n" +
            "        {\n" +
            "            \"type\": \"" + validations_type + "\",\n" +
            "            \"name\": \"" + validations_name + "\",\n" +
            "            \"description\": \"" + validations_description + "\"\n" +
            "        }\n" +
            "    ]\n" +
            "}";
    assertCheck("Fail", statusList);

}
catch (Exception e){

}
        return strBody;  }

    public String order_StrBody(DataTable table) {
        String organizationId = orgId;
        String contact_Id = contactId;
        List<List<String>> rows = table.asLists(String.class);
        for (List<String> columns : rows) {
            switch (columns.get(0)) {
                case "organizationId":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        organizationId = "";
                    } else if (!columns.get(1).equals("##################")) {
                        organizationId = columns.get(1);
                    } else {
                        organizationId = orgId;
                    }
                    statusList.add("Pass");
                    break;
                case "contacts_id":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        contactId = "";
                    } else if (!columns.get(1).equals("##################")) {
                        contactId = columns.get(1);
                    } else {
                        contact_Id = contactId;
                    }
                    statusList.add("Pass");
                    break;
                case "contact_type":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        contact_type = "";
                    } else {
                        contact_type = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "daysValid":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        daysValid = "";
                    } else {
                        daysValid = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "expirationType":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        expirationType = "";
                    } else {
                        expirationType = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "comments":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        comments = "";
                    } else {
                        comments = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;

                case "certType":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        certType = "";
                    } else {
                        certType = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "locale":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        locale = "";
                    } else {
                        locale = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "accountId":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        accountId = "";
                    } else {
                        accountId = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "provider":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        provider = "";
                    } else {
                        provider = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                default:
                    log.info("Menu item not found");
                    statusList.add("Fail");
                    break;

            }
        }
        strBody = "{\n" +
                "    \"organizationId\": \"" + organizationId + "\",\n" +
                "    \"contacts\": [\n" +
                "        {\n" +
                "            \"id\": \"" + contact_Id + "\",\n" +
                "            \"contactTypes\": [\n" +
                "                {\n" +
                "                    \"type\": \"" + contact_type + "\"\n" +
                "                }\n" +
                "            ]\n" +
                "        }\n" +
                "    ],\n" +
                "    \"daysValid\": " + daysValid + ",\n" +
                "    \"expirationType\": \"" + expirationType + "\",\n" +
                "    \"comments\": \"" + comments + "\",\n" +
                "    \"certType\": \"" + certType + "\",\n" +
                "    \"locale\": \"" + locale + "\",\n" +
                "    \"accountId\": " + accountId + ",\n" +
                "    \"provider\": \"" + provider + "\",\n" +
                "    \"cert\": " + certString + "\n" +
                "}";
        assertCheck("Fail", statusList);
        return strBody;
    }

    public String order_StrBody(String element, String elevalue) {
        String organizationId = orgId;
        String contact_Id = contactId;
        switch (element) {
            case "organizationId":
                if (elevalue.equalsIgnoreCase("")) {
                    organizationId = "";
                } else if (!elevalue.equals("##################")) {
                    organizationId = elevalue;
                } else {
                    organizationId = orgId;
                }
                statusList.add("Pass");
                break;
            case "contacts_id":
                if (elevalue.equalsIgnoreCase("")) {
                    contact_Id = "";
                } else if (!elevalue.equals("##################")) {
                    contact_Id = elevalue;
                } else {
                    contact_Id = contactId;
                }
                statusList.add("Pass");
                break;
            case "contact_type":
                if (elevalue.equalsIgnoreCase("")) {
                    contact_type = "";
                } else {
                    contact_type = elevalue;
                }
                statusList.add("Pass");
                break;
            case "daysValid":
                if (elevalue.equalsIgnoreCase("")) {
                    daysValid = "";
                } else {
                    daysValid = elevalue;
                }
                statusList.add("Pass");
                break;
            case "expirationType":
                if (elevalue.equalsIgnoreCase("")) {
                    expirationType = "";
                } else {
                    expirationType = elevalue;
                }
                statusList.add("Pass");
                break;
            case "comments":
                if (elevalue.equalsIgnoreCase("")) {
                    comments = "";
                } else {
                    comments = elevalue;
                }
                statusList.add("Pass");
                break;

            case "certType":
                if (elevalue.equalsIgnoreCase("")) {
                    certType = "";
                } else {
                    certType = elevalue;
                }
                statusList.add("Pass");
                break;
            case "locale":
                if (elevalue.equalsIgnoreCase("")) {
                    locale = "";
                } else {
                    locale = elevalue;
                }
                statusList.add("Pass");
                break;
            case "accountId":
                if (elevalue.equalsIgnoreCase("")) {
                    accountId = "";
                } else {
                    accountId = elevalue;
                }
                statusList.add("Pass");
                break;
            case "provider":
                if (elevalue.equalsIgnoreCase("")) {
                    provider = "";
                } else {
                    provider = elevalue;
                }
                statusList.add("Pass");
                break;
            default:
                log.info("Menu item not found");
                statusList.add("Fail");
                break;


        }
        strBody = "{\n" +
                "    \"organizationId\": \"" + organizationId + "\",\n" +
                "    \"contacts\": [\n" +
                "        {\n" +
                "            \"id\": \"" + contact_Id + "\",\n" +
                "            \"contactTypes\": [\n" +
                "                {\n" +
                "                    \"type\": \"" + contact_type + "\"\n" +
                "                }\n" +
                "            ]\n" +
                "        }\n" +
                "    ],\n" +
                "    \"daysValid\": " + daysValid + ",\n" +
                "    \"expirationType\": \"" + expirationType + "\",\n" +
                "    \"comments\": \"" + comments + "\",\n" +
                "    \"certType\": \"" + certType + "\",\n" +
                "    \"locale\": \"" + locale + "\",\n" +
                "    \"accountId\": " + accountId + ",\n" +
                "    \"provider\": \"" + provider + "\",\n" +
                "    \"cert\": " + certString + "\n" +
                "}";
        assertCheck("Fail", statusList);
        return strBody;
    }

    public String domain_StrBody(DataTable table) {
        String organizationId = orgId;
        domainName = "Automation" + getCurrentDate("ddmmyyyyhhmmss") + ".net";

        List<List<String>> rows = table.asLists(String.class);
        for (List<String> columns : rows) {
            switch (columns.get(0)) {
                case "organizationId":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        organizationId = "";
                    } else if (!columns.get(1).equals("##################")) {
                        organizationId = columns.get(1);
                    } else {
                        organizationId = orgId;
                    }
                    statusList.add("Pass");
                    break;

                case "provider":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        provider = "";
                    } else {
                        provider = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "name":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        domainName = "";
                    } else if (columns.get(1).equalsIgnoreCase("##################")) {
                        domainName = "Automation" + getCurrentDate("ddmmyyyyhhmmss") + ".net";
                    } else {
                        domainName = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "dcvMethod":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        dcvMethod = "";
                    } else {
                        dcvMethod = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;

                case "accountId":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        accountId = "";
                    } else {
                        accountId = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "validation_type":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        validation_type = "";
                    } else {
                        validation_type = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                default:
                    log.info("Menu item not found");
                    statusList.add("Fail");
                    break;

            }
        }
        strBody = "  {\n" +
                "    \"name\" : \"" + domainName + "\",\n" +
                "    \"provider\":\"" + provider + "\",\n" +
                "    \"organizationId\":\"" + organizationId + "\",\n" +
                "    \"dcvMethod\" : \"" + dcvMethod + "\",\n" +
                "    \"validations\" : [{\n" +
                "        \"type\" : \"" + validation_type + "\"\n" +
                "    }],\n" +
                "    \"accountId\": " + accountId + "\n" +
                "}";
        assertCheck("Fail", statusList);
        return strBody;
    }

    public String domain_StrBody(String element, String elevalue) {
        String organizationId = orgId;
        domainName = "Automation" + getCurrentDate("ddmmyyyyhhmmss") + ".net";
        switch (element) {
            case "organizationId":
                if (elevalue.equalsIgnoreCase("")) {
                    organizationId = "";
                } else if (!elevalue.equals("##################")) {
                    organizationId = elevalue;
                } else {
                    organizationId = orgId;
                }
                statusList.add("Pass");
                break;

            case "provider":
                if (elevalue.equalsIgnoreCase("")) {
                    provider = "";
                } else {
                    provider = elevalue;
                }
                statusList.add("Pass");
                break;
            case "name":
                if (elevalue.equalsIgnoreCase("")) {
                    domainName = "";
                } else if (elevalue.equalsIgnoreCase("##################")) {
                    domainName = "Automation" + getCurrentDate("ddmmyyyyhhmmss") + ".net";
                } else {
                    domainName = elevalue;
                }
                statusList.add("Pass");
                break;
            case "dcvMethod":
                if (elevalue.equalsIgnoreCase("")) {
                    dcvMethod = "";
                } else {
                    dcvMethod = elevalue;
                }
                statusList.add("Pass");
                break;

            case "accountId":
                if (elevalue.equalsIgnoreCase("")) {
                    accountId = "";
                } else {
                    accountId = elevalue;
                }
                statusList.add("Pass");
                break;
            case "validation_type":
                if (elevalue.equalsIgnoreCase("")) {
                    validation_type = "";
                } else {
                    validation_type = elevalue;
                }
                statusList.add("Pass");
                break;
            default:
                log.info("Menu item not found");
                statusList.add("Fail");
                break;
        }
        strBody = "  {\n" +
                "    \"name\" : \"" + domainName + "\",\n" +
                "    \"provider\":\"" + provider + "\",\n" +
                "    \"organizationId\":\"" + organizationId + "\",\n" +
                "    \"dcvMethod\" : \"" + dcvMethod + "\",\n" +
                "    \"validations\" : [{\n" +
                "        \"type\" : \"" + validation_type + "\"\n" +
                "    }],\n" +
                "    \"accountId\": " + accountId + "\n" +
                "}";
        assertCheck("Fail", statusList);
        return strBody;
    }

    public String orderFromProverId_StrBody(DataTable table) {
        String organizationId = orgId;
        String contact_Id = contactId;

        List<List<String>> rows = table.asLists(String.class);
        for (List<String> columns : rows) {
            switch (columns.get(0)) {
                case "organizationId":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        orgId = "";
                    } else if (!columns.get(1).equals("##################")) {
                        orgId = columns.get(1);
                    } else {
                        organizationId = orgId;
                    }
                    statusList.add("Pass");
                    break;
                case "contacts_id":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        contactId = "";
                    } else if (!columns.get(1).equals("##################")) {
                        contactId = columns.get(1);
                    } else {
                        contact_Id = contactId;
                    }
                    statusList.add("Pass");
                    break;
                case "contact_type":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        contact_type = "";
                    } else {
                        contact_type = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "daysValid":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        daysValid = "";
                    } else {
                        daysValid = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "expirationType":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        expirationType = "";
                    } else {
                        expirationType = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "comments":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        comments = "";
                    } else {
                        comments = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;

                case "certType":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        certType = "";
                    } else {
                        certType = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "locale":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        locale = "";
                    } else {
                        locale = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "accountId":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        accountId = "";
                    } else {
                        accountId = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "provider":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        provider = "";
                    } else {
                        provider = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "commonName":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        commonName = "";
                    } else {
                        commonName = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;


                case "csr":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        csr = "";
                    } else {
                        csr = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "serverPlatform":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        serverPlatform = "";
                    } else {
                        serverPlatform = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;

                case "signatureHash":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        signatureHash = "";
                    } else {
                        signatureHash = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;

                case "dcvMethod":
                    if (columns.get(1).equalsIgnoreCase("")) {
                        dcvMethod = "";
                    } else {
                        dcvMethod = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;

                default:
                    log.info("Menu item not found");
                    statusList.add("Fail");
                    break;

            }
        }
        strBody = "{\n" +
                "    \"organizationId\": \"" + orgId + "\",\n" +
                "    \"contacts\": [\n" +
                "        {\n" +
                "            \"id\": \"" + contactId + "\",\n" +
                "            \"contactTypes\": [\n" +
                "                {\n" +
                "                    \"type\": \"ORGANIZATION_CONTACT\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"accountId\": 3938\n" +
                "        }\n" +
                "    ],\n" +
                "    \"accountId\": 3938,\n" +
                "    \"provider\": \"DIGICERT\",\n" +
                "    \"providerId\": 118511964\n" +
                "}";
        assertCheck("Fail", statusList);
        return strBody;
    }


//***********************DNS methods ***************************//


    public String getZone_StrBody(DataTable table) {
        List<List<String>> rows = table.asLists(String.class);
        zoneName = "";

        for (List<String> columns : rows) {
            switch (columns.get(0)) {
                case "zoneName":
                    if (columns.get(1) == null) {
                        zoneName = "";
                    } else if (columns.get(1).equals("##################")) {
                        zoneName = "Automation-" + (99900000 + new Random().nextInt(10000) + ".com");
                    } else {
                        zoneName = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "status":
                    if (columns.get(1) == null) {
                        status = "";
                    } else {
                        status = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "accountId":
                    if (columns.get(1) == null) {
                        accountId = "";
                    } else {
                        accountId = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "apiType":
                    if (columns.get(1) == null) {
                        api_Type = "";
                    } else {
                        api_Type = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "template":
                    if (columns.get(1) == null) {
                        template = "";
                    } else {
                        template = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "zoneType":
                    if (columns.get(1) == null) {
                        zoneType = "";
                    } else {
                        zoneType = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "expires":
                    if (columns.get(1) == null) {
                        expires = "";
                    } else {
                        expires = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "recordsData":
                    if (columns.get(1) == null) {
                        recordsData = "";
                    } else {
                        recordsData = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "recordsTtl":
                    if (columns.get(1) == null) {
                        recordsTtl = "";
                    } else {
                        recordsTtl = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "recordsName":
                    if (columns.get(1) == null) {
                        recordsName = "";
                    } else {
                        recordsName = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "recordsRefresh":
                    if (columns.get(1) == null) {
                        recordsRefresh = "";
                    } else {
                        recordsRefresh = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "recordsRetry":
                    if (columns.get(1) == null) {
                        recordsRetry = "";
                    } else {
                        recordsRetry = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "recordsSerial":
                    if (columns.get(1) == null) {
                        recordsSerial = "";
                    } else {
                        recordsSerial = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "recordsOrmid":
                    if (columns.get(1) == null) {
                        recordsOrmid = "";
                    } else {
                        recordsOrmid = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "recordsType":
                    if (columns.get(1) == null) {
                        recordsType = "";
                    } else {
                        recordsType = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                default:
                    log.info("Menu item not found");
                    statusList.add("Fail");
                    break;
            }

        }

        String strBody = "    {\n" +
                "        \"accountId\": " + accountId + ",\n" +
                "            \"name\": \"" + zoneName + "\",\n" +
                "            \"status\": \"" + status + "\",\n" +
                "            \"apiType\": \"" + api_Type + "\",\n" +
                "            \"template\": " + template + ",\n" +
                "            \"zoneType\": \"" + zoneType + "\",\n" +
                "            \"expires\": \"" + expires + "T16:27:32.143+0000\",\n" +
                "            \"records\": [\n" +
                "        {   \"data\": \"" + recordsData + "\",\n" +
                "                \"ttl\": " + recordsTtl + ",\n" +
                "                \"name\": \"" + recordsName + "\",\n" +
                "                \"refresh\": " + recordsRefresh + ",\n" +
                "                \"retry\": " + recordsRetry + ",\n" +
                "                \"serial\": " + recordsSerial + ",\n" +
                "                \"ormid\": " + recordsOrmid + ",\n" +
                "                \"type\": \"" + recordsType + "\"\n" +
                "        }\n" +
                "    ]\n" +
                "    }";
        assertCheck("Fail", statusList);
        return strBody;
    }

    public String getZone_StrBody(String element, String elevalue) {
        zoneName = "Automation-" + (99900000 + new Random().nextInt(10000) + ".com");
        switch (element) {
            case "zoneName":
                if (elevalue == null) {
                    zoneName = "";
                } else if (elevalue.equals("##################")) {
                    zoneName = "Automation-" + (99900000 + new Random().nextInt(10000) + ".com");
                } else {
                    zoneName = elevalue;
                }
                statusList.add("Pass");
                break;
            case "status":
                if (elevalue == null) {
                    status = "";
                } else {
                    status = elevalue;
                }
                statusList.add("Pass");
                break;
            case "accountId":
                if (elevalue == null) {
                    accountId = "";
                } else {
                    accountId = elevalue;
                }
                statusList.add("Pass");
                break;
            case "apiType":
                if (elevalue == null) {
                    api_Type = "";
                } else {
                    api_Type = elevalue;
                }
                statusList.add("Pass");
                break;
            case "template":
                if (elevalue == null) {
                    template = "";
                } else {
                    template = elevalue;
                }
                statusList.add("Pass");
                break;
            case "zoneType":
                if (elevalue == null) {
                    zoneType = "";
                } else {
                    zoneType = elevalue;
                }
                statusList.add("Pass");
                break;
            case "expires":
                if (elevalue == null) {
                    expires = "";
                } else {
                    expires = elevalue;
                }
                statusList.add("Pass");
                break;
            case "recordsData":
                if (elevalue == null) {
                    recordsData = "";
                } else {
                    recordsData = elevalue;
                }
                statusList.add("Pass");
                break;
            case "recordsTtl":
                if (elevalue == null) {
                    recordsTtl = "";
                } else {
                    recordsTtl = elevalue;
                }
                statusList.add("Pass");
                break;
            case "recordsName":
                if (elevalue == null) {
                    recordsName = "";
                } else {
                    recordsName = elevalue;
                }
                statusList.add("Pass");
                break;
            case "recordsRefresh":
                if (elevalue == null) {
                    recordsRefresh = "";
                } else {
                    recordsRefresh = elevalue;
                }
                statusList.add("Pass");
                break;
            case "recordsRetry":
                if (elevalue == null) {
                    recordsRetry = "";
                } else {
                    recordsRetry = elevalue;
                }
                statusList.add("Pass");
                break;
            case "recordsSerial":
                if (elevalue == null) {
                    recordsSerial = "";
                } else {
                    recordsSerial = elevalue;
                }
                statusList.add("Pass");
                break;
            case "recordsOrmid":
                if (elevalue == null) {
                    recordsOrmid = "";
                } else {
                    recordsOrmid = elevalue;
                }
                statusList.add("Pass");
                break;
            case "recordsType":
                if (elevalue == null) {
                    recordsType = "";
                } else {
                    recordsType = elevalue;
                }
                statusList.add("Pass");
                break;
            default:
                log.info("Menu item not found");
                statusList.add("Fail");
                break;
        }
        String strBody = "    {\n" +
                "        \"accountId\": " + accountId + ",\n" +
                "            \"name\": \"" + zoneName + "\",\n" +
                "            \"status\": \"" + status + "\",\n" +
                "            \"apiType\": \"" + api_Type + "\",\n" +
                "            \"template\": " + template + ",\n" +
                "            \"zoneType\": \"" + zoneType + "\",\n" +
                "            \"expires\": \"" + expires + "T16:27:32.143+0000\",\n" +
                "            \"records\": [\n" +
                "        {   \"data\": \"" + recordsData + "\",\n" +
                "                \"ttl\": " + recordsTtl + ",\n" +
                "                \"name\": \"" + recordsName + "\",\n" +
                "                \"refresh\": " + recordsRefresh + ",\n" +
                "                \"retry\": " + recordsRetry + ",\n" +
                "                \"serial\": " + recordsSerial + ",\n" +
                "                \"ormid\": " + recordsOrmid + ",\n" +
                "                \"type\": \"" + recordsType + "\"\n" +
                "        }\n" +
                "    ]\n" +
                "    }";
        assertCheck("Fail", statusList);
        return strBody;

    }


    public String getRecord_StrBody(DataTable table) {
        List<List<String>> rows = table.asLists(String.class);
        String zoneid = zoneId;
        for (List<String> columns : rows) {
            switch (columns.get(0)) {
                case "name":
                    if (columns.get(1) == null) {
                        name = "";
                    } else if (columns.get(1).equals("##################")) {
                        name = "Automation-" + (99900000 + new Random().nextInt(10000));
                    } else {
                        name = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "data":
                    if (columns.get(1) == null) {
                        data = "";
                    } else {
                        data = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "type":
                    if (columns.get(1) == null) {
                        recordtype = "";
                    } else {
                        recordtype = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "ttl":
                    if (columns.get(1) == null) {
                        ttl = "";
                    } else {
                        ttl = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "zoneid":
                    zoneid = getColumnValue(columns.get(1));
                    statusList.add("Pass");
                    break;
                default:
                    log.info("Menu item not found");
                    statusList.add("Fail");
                    break;
            }
        }
        String strBody = "{\n" +
                "    \"name\": \"" + name + "\",\n" +
                "    \"data\": \"" + data + "\",\n" +
                "    \"type\": \"" + recordtype + "\",\n" +
                "    \"ttl\": " + ttl + ",\n" +
                "    \"zoneId\": \"" + zoneid + "\"\n" +
                "}";
        assertCheck("Fail", statusList);
        return strBody;
    }


    public String getRecord_StrBody(String element, String elevalue) {
        String zoneid = zoneId;

        switch (element) {
            case "name":
                if (elevalue == null) {
                    name = "";
                } else if (elevalue.equals("##################")) {
                    name = "Automation-" + (99900000 + new Random().nextInt(10000));
                } else {
                    name = elevalue;
                }
                statusList.add("Pass");
                break;
            case "data":
                if (elevalue == null) {
                    data = "";
                } else {
                    data = elevalue;
                }
                statusList.add("Pass");
                break;
            case "type":
                if (elevalue == null) {
                    recordtype = "";
                } else {
                    recordtype = elevalue;
                }
                statusList.add("Pass");
                break;
            case "ttl":
                if (elevalue == null) {
                    ttl = "";
                } else {
                    ttl = elevalue;
                }
                statusList.add("Pass");
                break;
            case "zoneid":
                if (elevalue == null) {
                    zoneid = "";
                } else if (elevalue.equals("##################")) {
                    zoneid = zoneId;
                } else {
                    zoneid = elevalue;
                }
                statusList.add("Pass");
                break;
            default:
                log.info("Menu item not found");
                statusList.add("Fail");
                break;

        }
        String strBody = "{\n" +
                "    \"name\": \"" + name + "\",\n" +
                "    \"data\": \"" + data + "\",\n" +
                "    \"type\": \"" + recordtype + "\",\n" +
                "    \"ttl\": " + ttl + ",\n" +
                "    \"zoneId\": \"" + zoneid + "\"\n" +
                "}";
        assertCheck("Fail", statusList);
        return strBody;
    }


    public String getRecord_StrBody_Patch(String element, String elevalue) {
        switch (element) {
            case "name":
                strBody = "{\n" +
                        "    \"name\": \"" + elevalue + "\"\n" +
                        "}";
                statusList.add("Pass");
                break;
            case "data":
                strBody = "{\n" +
                        "    \"data\": \"" + elevalue + "\"\n" +
                        "}";
                statusList.add("Pass");
                break;
            case "type":
                strBody = "{\n" +
                        "    \"type\": \"" + elevalue + "\"\n" +
                        "}";
                statusList.add("Pass");
                break;
            case "ttl":
                strBody = "{\n" +
                        "    \"ttl\": " + elevalue + "\n" +
                        "}";
                statusList.add("Pass");
                break;
            case "zoneid":
                strBody = "{\n" +
                        "    \"zoneId\": \"" + elevalue + "\"\n" +
                        "}";
                statusList.add("Pass");
                break;
            default:
                log.info("Menu item not found");
                statusList.add("Fail");
                break;

        }

        assertCheck("Fail", statusList);
        return strBody;
    }

    public String getWebForwarding_StrBody(DataTable table) {
        List<List<String>> rows = table.asLists(String.class);
        String forwardTo = "http://qatesdsdstforwardnotpremium.com";
        String forwardFrom = "forwardnotpsdsdremiumtest02.com";
        String premium = "false";
        String numNameServers = "4";
        String accountId = "27";
        String forwardType = "PERMANENT";
        String templateId = "f8ecbf5f-5935-46fb-a31a-12c857482daf";
        for (List<String> columns : rows) {
            switch (columns.get(0)) {
                case "forwardTo":
                    if (columns.get(1) == null) {
                        forwardTo = "";
                    } else if (columns.get(1).equals("##################")) {
                        forwardTo = "http://AutomationForwardTo" + getCurrentDate("dd_mm_yyyy_hh_mm_ss") + ".com";
                    } else {
                        forwardTo = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "forwardFrom":
                    if (columns.get(1) == null) {
                        forwardFrom = "";
                    } else if (columns.get(1).equals("##################")) {
                        forwardFrom = "AutomationForwardFrom" + getCurrentDate("dd_mm_yyyy_hh_mm_ss") + ".com";
                    } else {
                        forwardFrom = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "premium":
                    if (columns.get(1) == null) {
                        premium = "";
                    } else {
                        premium = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "numNameServers":
                    if (columns.get(1) == null) {
                        numNameServers = "";
                    } else {
                        numNameServers = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "accountId":
                    if (columns.get(1) == null) {
                        accountId = "";
                    } else {
                        accountId = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "forwardType":
                                     if (columns.get(1) == null) {
                        forwardType = "";
                    } else {
                        forwardType = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                case "templateId":
                    if (columns.get(1) == null) {
                        templateId = "";
                    } else {
                        templateId = columns.get(1);
                    }
                    statusList.add("Pass");
                    break;
                default:
                    log.info("Menu item not found");
                    statusList.add("Fail");
                    break;
            }
        }
        String strBody = "\n" +
                "{\n" +
                "  \"forwardTo\": \""+forwardTo+"\",\n" +
                "  \"forwardFrom\": \""+forwardFrom+"\",\n" +
                "  \"premium\": "+premium+",\n" +
                "  \"numNameServers\": "+numNameServers+",\n" +
                "  \"accountId\": \""+accountId+"\",\n" +
                "  \"forwardType\":\""+forwardType+"\",\n" +
                "  \"templateId\": \""+templateId+"\"\n" +
                "}\n";
        assertCheck("Fail", statusList);
        return strBody;
    }

    public String getWebForwarding_StrBody(String element, String elevalue) {
        String forwardTo = "http://qatesdsdstforwardnotpremium.com";
        String forwardFrom = "forwardnotpsdsdremiumtest02.com";
        String premium = "false";
        String numNameServers = "4";
        String accountId = "27";
        String forwardType = "PERMANENT";
        String templateId = "f8ecbf5f-5935-46fb-a31a-12c857482daf";
        switch (element) {
            case "forwardTo":
                if (elevalue == null) {
                    forwardTo = "";
                } else if (elevalue.equals("##################")) {
                    forwardTo = "http://AutomationForwardTo" + getCurrentDate("dd_mm_yyyy_hh_mm_ss") + ".com";
                } else {
                    forwardTo = elevalue;
                }
                statusList.add("Pass");
                break;
            case "forwardFrom":
                if (elevalue == null) {
                    forwardFrom = "";
                } else if (elevalue.equals("##################")) {
                    forwardFrom = "AutomationForwardFrom" + getCurrentDate("dd_mm_yyyy_hh_mm_ss") + ".com";
                } else {
                    forwardFrom = elevalue;
                }
                statusList.add("Pass");
                break;
            case "premium":
                if (elevalue == null) {
                    premium = "";
                } else {
                    premium = elevalue;
                }
                statusList.add("Pass");
                break;
            case "numNameServers":
                if (elevalue == null) {
                    numNameServers = "";
                } else {
                    numNameServers = elevalue;
                }
                statusList.add("Pass");
                break;
            case "accountId":
                if (elevalue == null) {
                    accountId = "";
                } else {
                    accountId = elevalue;
                }
                statusList.add("Pass");
                break;
            case "forwardType":
                if (elevalue == null) {
                    forwardType = "";
                } else {
                    forwardType = elevalue;
                }
                statusList.add("Pass");
                break;
            case "templateId":
                if (elevalue == null) {
                    templateId = "";
                } else {
                    templateId = elevalue;
                }
                statusList.add("Pass");
                break;
            default:
                log.info("Menu item not found");
                statusList.add("Fail");
                break;
        }
        String strBody = "\n" +
                "{\n" +
                "  \"forwardTo\": \""+forwardTo+"\",\n" +
                "  \"forwardFrom\": \""+forwardFrom+"\",\n" +
                "  \"premium\": "+premium+",\n" +
                "  \"numNameServers\": "+numNameServers+",\n" +
                "  \"accountId\": \""+accountId+"\",\n" +
                "  \"forwardType\":\""+forwardType+"\",\n" +
                "  \"templateId\": \""+templateId+"\"\n" +
                "}\n";
        assertCheck("Fail", statusList);
        return strBody;
    }

    private String getColumnValue(String columnName) {
        String columnValue;
        if (columnName == null) {
            columnValue = "";
        } else if (columnName.equals("##################")) {
            columnValue = zoneId;
        } else {
            columnValue = columnName;
        }
        return columnValue;
    }

}


